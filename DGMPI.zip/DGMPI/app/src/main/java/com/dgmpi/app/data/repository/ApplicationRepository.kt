package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.ApplicationSubmission
import com.dgmpi.app.data.model.ApplicationType
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeList
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

interface ApplicationRepository {
    fun observeApplicationTypes(): Flow<Resource<List<ApplicationType>>>
    fun observeMySubmissions(studentId: String): Flow<Resource<List<ApplicationSubmission>>>
    suspend fun submit(submission: ApplicationSubmission): Resource<Unit>
}

@Singleton
class ApplicationRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : ApplicationRepository {

    override fun observeApplicationTypes(): Flow<Resource<List<ApplicationType>>> =
        firestore.collection("application_types").observeList()

    override fun observeMySubmissions(studentId: String): Flow<Resource<List<ApplicationSubmission>>> =
        firestore.collection(FirestorePaths.APPLICATIONS)
            .whereEqualTo("studentId", studentId)
            .orderBy("submittedAtMillis", Query.Direction.DESCENDING)
            .observeList()

    override suspend fun submit(submission: ApplicationSubmission): Resource<Unit> = try {
        firestore.collection(FirestorePaths.APPLICATIONS).add(submission).await()
        Resource.Success(Unit)
    } catch (e: Exception) {
        Resource.Error(e.message ?: "Failed to submit application", e)
    }
}
