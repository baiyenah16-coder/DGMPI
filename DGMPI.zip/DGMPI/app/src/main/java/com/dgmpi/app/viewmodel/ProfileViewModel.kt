package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.Student
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.repository.StorageRepository
import com.dgmpi.app.data.repository.StudentRepository
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val studentRepository: StudentRepository,
    private val storageRepository: StorageRepository,
    private val firestore: FirebaseFirestore
) : ViewModel() {

    private val _student = MutableStateFlow<Resource<Student?>>(Resource.Loading)
    val student: StateFlow<Resource<Student?>> = _student.asStateFlow()

    private val _isUploadingPhoto = MutableStateFlow(false)
    val isUploadingPhoto: StateFlow<Boolean> = _isUploadingPhoto.asStateFlow()

    private var job: Job? = null
    private var boundId: String? = null

    fun bindStudent(studentId: String) {
        if (boundId == studentId) return
        boundId = studentId
        job?.cancel()
        job = viewModelScope.launch {
            studentRepository.observeStudent(studentId).collect { _student.value = it }
        }
    }

    fun uploadProfilePhoto(studentId: String, uri: android.net.Uri) {
        viewModelScope.launch {
            _isUploadingPhoto.value = true
            when (val result = storageRepository.uploadFile(FirestorePaths.STORAGE_STUDENT_PHOTOS, uri)) {
                is Resource.Success -> {
                    firestore.collection(FirestorePaths.STUDENTS).document(studentId)
                        .update("photoUrl", result.data)
                }
                else -> Unit
            }
            _isUploadingPhoto.value = false
        }
    }
}
