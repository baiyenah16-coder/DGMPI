package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.IssuedBook
import com.dgmpi.app.data.model.TaskItem
import com.dgmpi.app.data.repository.LibraryRepository
import com.dgmpi.app.data.repository.TaskRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TaskViewModel @Inject constructor(
    private val repository: TaskRepository
) : ViewModel() {

    private val _tasks = MutableStateFlow<Resource<List<TaskItem>>>(Resource.Loading)
    val tasks: StateFlow<Resource<List<TaskItem>>> = _tasks.asStateFlow()

    private var boundId: String? = null

    fun bindStudent(studentId: String) {
        if (boundId == studentId) return
        boundId = studentId
        viewModelScope.launch { repository.observeTasks(studentId).collect { _tasks.value = it } }
    }

    fun addTask(studentId: String, title: String, dueDate: String, priority: String = "Normal") {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.addTask(
                TaskItem(
                    studentId = studentId,
                    title = title,
                    dueDate = dueDate.ifBlank { "No date" },
                    priority = priority
                )
            )
        }
    }

    fun toggleDone(taskId: String, isDone: Boolean) {
        viewModelScope.launch { repository.toggleDone(taskId, isDone) }
    }

    fun deleteTask(taskId: String) {
        viewModelScope.launch { repository.deleteTask(taskId) }
    }
}

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val repository: LibraryRepository
) : ViewModel() {

    private val _issuedBooks = MutableStateFlow<Resource<List<IssuedBook>>>(Resource.Loading)
    val issuedBooks: StateFlow<Resource<List<IssuedBook>>> = _issuedBooks.asStateFlow()

    private var boundId: String? = null

    fun bindStudent(studentId: String) {
        if (boundId == studentId) return
        boundId = studentId
        viewModelScope.launch { repository.observeIssuedBooks(studentId).collect { _issuedBooks.value = it } }
    }
}
