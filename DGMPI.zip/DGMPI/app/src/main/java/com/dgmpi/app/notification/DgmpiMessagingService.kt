package com.dgmpi.app.notification

import com.dgmpi.app.data.repository.AuthRepository
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Receives all push categories the Admin Panel can send: Notice, Result Published,
 * Routine Updated, Event, and Emergency Notice. The Admin decides the "type" data field;
 * this service just renders title/body and lets MainActivity's NavGraph route the tap
 * (deep-linking is handled at the Activity/NavGraph layer using the "route" data field).
 */
@AndroidEntryPoint
class DgmpiMessagingService : FirebaseMessagingService() {

    @Inject lateinit var authRepository: AuthRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val title = message.notification?.title ?: message.data["title"] ?: "DGMPI"
        val body = message.notification?.body ?: message.data["body"] ?: ""
        NotificationHelper.buildAndShow(applicationContext, title, body)
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        serviceScope.launch {
            authRepository.updateFcmToken(token)
        }
    }
}
