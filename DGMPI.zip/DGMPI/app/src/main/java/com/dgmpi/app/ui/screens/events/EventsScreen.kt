package com.dgmpi.app.ui.screens.events

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.components.SectionCard
import com.dgmpi.app.ui.theme.Gold
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.EventViewModel

@Composable
fun EventsScreen(onBack: () -> Unit, viewModel: EventViewModel = hiltViewModel()) {
    val eventsState by viewModel.events.collectAsState()

    Scaffold(
        topBar = { GradientHeader(title = "Events", subtitle = "Upcoming institute events", onBack = onBack) }
    ) { padding ->
        when (val state = eventsState) {
            is Resource.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Navy)
            }
            is Resource.Error -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(state.message, color = MaterialTheme.colorScheme.error)
            }
            is Resource.Success -> {
                if (state.data.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(padding)) {
                        EmptyState("No upcoming events yet.", modifier = Modifier.align(Alignment.Center))
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(state.data, key = { it.id }) { event ->
                            SectionCard {
                                if (event.imageUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = event.imageUrl,
                                        contentDescription = event.title,
                                        modifier = Modifier.fillMaxWidth().height(140.dp)
                                            .background(Gold.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                }
                                Text(event.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.CalendarMonth, contentDescription = null, tint = Navy, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(event.date, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    if (event.location.isNotBlank()) {
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Icon(Icons.Filled.LocationOn, contentDescription = null, tint = Navy, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(event.location, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(event.description, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}
