package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.Teacher
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeList
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

interface TeacherRepository {
    fun observeTeachers(): Flow<Resource<List<Teacher>>>
}

@Singleton
class TeacherRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : TeacherRepository {
    override fun observeTeachers(): Flow<Resource<List<Teacher>>> =
        firestore.collection(FirestorePaths.TEACHERS)
            .orderBy("name")
            .observeList()
}
