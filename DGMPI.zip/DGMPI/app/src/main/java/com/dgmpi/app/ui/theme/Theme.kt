package com.dgmpi.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColors = lightColorScheme(
    primary = Navy,
    onPrimary = PureWhite,
    primaryContainer = NavyLight,
    onPrimaryContainer = PureWhite,
    secondary = Gold,
    onSecondary = NavyDark,
    secondaryContainer = GoldLight,
    onSecondaryContainer = NavyDark,
    background = OffWhite,
    onBackground = SlateText,
    surface = PureWhite,
    onSurface = SlateText,
    surfaceVariant = Color2(0xFFEDEFF3),
    onSurfaceVariant = MutedText,
    error = ErrorRed,
    outline = Color2(0xFFD8DCE3)
)

private val DarkColors = darkColorScheme(
    primary = GoldLight,
    onPrimary = NavyDark,
    primaryContainer = Navy,
    onPrimaryContainer = PureWhite,
    secondary = Gold,
    onSecondary = NavyDark,
    secondaryContainer = NavyLight,
    onSecondaryContainer = PureWhite,
    background = DarkSurface,
    onBackground = DarkOnSurface,
    surface = DarkSurfaceVariant,
    onSurface = DarkOnSurface,
    error = ErrorRed
)

// small helper so Color.kt import list stays uncluttered
private fun Color2(value: Long) = androidx.compose.ui.graphics.Color(value)

@Composable
fun DgmpiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = DgmpiTypography,
        content = content
    )
}
