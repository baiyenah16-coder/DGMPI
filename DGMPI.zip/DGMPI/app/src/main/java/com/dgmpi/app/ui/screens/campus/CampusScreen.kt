package com.dgmpi.app.ui.screens.campus

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.dgmpi.app.ui.components.*
import com.dgmpi.app.ui.theme.Gold
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.CampusViewModel

@Composable
fun CampusScreen(onBack: () -> Unit, onOpenGallery: () -> Unit, viewModel: CampusViewModel = hiltViewModel()) {
    val infoState by viewModel.campusInfo.collectAsState()
    val departmentsState by viewModel.departments.collectAsState()
    val facilitiesState by viewModel.facilities.collectAsState()
    val galleryState by viewModel.gallery.collectAsState()

    Scaffold(
        topBar = { GradientHeader(title = "Our Campus", subtitle = "Discover our institute", onBack = onBack) }
    ) { padding ->
        when (val resource = infoState) {
            is Resource.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Navy)
            }
            is Resource.Error -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(resource.message, color = MaterialTheme.colorScheme.error)
            }
            is Resource.Success -> {
                val info = resource.data
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (info != null && info.bannerImageUrl.isNotBlank()) {
                        item {
                            AsyncImage(
                                model = info.bannerImageUrl,
                                contentDescription = "Campus banner",
                                modifier = Modifier.fillMaxWidth().height(160.dp).background(Navy.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                            )
                        }
                    }
                    item {
                        SectionCard {
                            SectionTitle("Campus Introduction", Icons.Filled.Domain)
                            Text(info?.introduction.orEmpty().ifBlank { "Campus introduction has not been published yet." }, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    if (info != null && info.atAGlance.isNotEmpty()) {
                        item {
                            SectionCard {
                                SectionTitle("At a Glance", Icons.Filled.Insights)
                                info.atAGlance.forEach { (label, value) ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(label, style = MaterialTheme.typography.bodyMedium)
                                        Text(value, fontWeight = FontWeight.Bold, color = Navy)
                                    }
                                }
                            }
                        }
                    }
                    item {
                        SectionCard {
                            SectionTitle("Principal's Message", Icons.Filled.RecordVoiceOver)
                            Row(verticalAlignment = Alignment.Top) {
                                IconBadge(Icons.Filled.Person)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(info?.principalMessage.orEmpty().ifBlank { "Principal's message has not been published yet." }, style = MaterialTheme.typography.bodyMedium)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(info?.principalName ?: "Principal, DGMPI", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                                }
                            }
                        }
                    }
                    item {
                        SectionCard {
                            SectionTitle("Departments", Icons.Filled.AccountTree)
                            when (val deptState = departmentsState) {
                                is Resource.Loading -> CircularProgressIndicator(color = Navy)
                                is Resource.Error -> Text(deptState.message, color = MaterialTheme.colorScheme.error)
                                is Resource.Success -> deptState.data.forEach { dept ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        IconBadge(Icons.Filled.School, backgroundColor = Navy.copy(alpha = 0.08f))
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(dept.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                            Text(dept.description, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                                            Text("HOD: ${dept.headOfDept}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    Divider()
                                }
                            }
                        }
                    }
                    item {
                        SectionCard {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                SectionTitle("Campus Gallery", Icons.Filled.PhotoLibrary)
                                TextButton(onClick = onOpenGallery) { Text("View All") }
                            }
                            when (val galState = galleryState) {
                                is Resource.Loading -> CircularProgressIndicator(color = Navy)
                                is Resource.Error -> Text(galState.message, color = MaterialTheme.colorScheme.error)
                                is Resource.Success -> {
                                    if (galState.data.isEmpty()) {
                                        Text("No gallery images yet.", style = MaterialTheme.typography.bodyMedium)
                                    } else {
                                        LazyVerticalGrid(
                                            columns = GridCells.Fixed(3),
                                            modifier = Modifier.height(180.dp),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            items(galState.data.take(6)) { img ->
                                                AsyncImage(
                                                    model = img.imageUrl,
                                                    contentDescription = img.caption,
                                                    modifier = Modifier.fillMaxWidth().height(80.dp).background(Gold.copy(alpha = 0.15f), RoundedCornerShape(10.dp))
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    item {
                        SectionCard {
                            SectionTitle("Campus Facilities", Icons.Filled.Apartment)
                            when (val facState = facilitiesState) {
                                is Resource.Loading -> CircularProgressIndicator(color = Navy)
                                is Resource.Error -> Text(facState.message, color = MaterialTheme.colorScheme.error)
                                is Resource.Success -> LazyVerticalGrid(
                                    columns = GridCells.Fixed(2),
                                    modifier = Modifier.height(260.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    items(facState.data) { facility ->
                                        Column(modifier = Modifier.background(MaterialTheme.colorScheme.background, RoundedCornerShape(12.dp)).padding(12.dp)) {
                                            Icon(IconMapper.get(facility.icon), contentDescription = null, tint = Navy)
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(facility.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                                            Text(facility.description, style = MaterialTheme.typography.labelSmall, maxLines = 3)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (info != null) {
                        item {
                            SectionCard {
                                SectionTitle("Vision & Mission", Icons.Filled.Flag)
                                Text("Vision", fontWeight = FontWeight.Bold)
                                Text(info.vision.ifBlank { "Not published yet." }, style = MaterialTheme.typography.bodyMedium)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Mission", fontWeight = FontWeight.Bold)
                                Text(info.mission.ifBlank { "Not published yet." }, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        item {
                            SectionCard {
                                SectionTitle("Location", Icons.Filled.Map)
                                Box(
                                    modifier = Modifier.fillMaxWidth().height(140.dp).background(Navy.copy(alpha = 0.08f), RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Filled.LocationOn, contentDescription = null, tint = Navy)
                                        Text(info.address.ifBlank { "Address not set" }, style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                        item {
                            SectionCard {
                                SectionTitle("Contact Information", Icons.Filled.ContactMail)
                                ContactRow(Icons.Filled.Call, info.phone.ifBlank { "Not set" })
                                ContactRow(Icons.Filled.Email, info.email.ifBlank { "Not set" })
                                ContactRow(Icons.Filled.LocationOn, info.address.ifBlank { "Not set" })
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ContactRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(modifier = Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = Navy, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}
