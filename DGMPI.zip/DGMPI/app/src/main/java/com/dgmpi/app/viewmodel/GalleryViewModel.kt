package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.GalleryImage
import com.dgmpi.app.data.repository.CampusRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

val galleryCategories = listOf(
    "Campus", "Classroom", "Lab", "Library", "Hostel", "Events", "Convocation", "Sports", "Cultural Program"
)

@HiltViewModel
class GalleryViewModel @Inject constructor(
    private val repository: CampusRepository
) : ViewModel() {

    private val _images = MutableStateFlow<Resource<List<GalleryImage>>>(Resource.Loading)
    val images: StateFlow<Resource<List<GalleryImage>>> = _images.asStateFlow()

    private var job: Job? = null
    var selectedCategory: String? = null
        private set

    init {
        selectCategory(null)
    }

    fun selectCategory(category: String?) {
        selectedCategory = category
        job?.cancel()
        _images.value = Resource.Loading
        job = viewModelScope.launch {
            repository.observeGallery(category).collect { _images.value = it }
        }
    }
}
