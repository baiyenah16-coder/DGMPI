package com.dgmpi.app.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.Student
import com.dgmpi.app.data.repository.AuthRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * App-wide shared state: authentication (backed by real Firebase Auth via [AuthRepository]),
 * theme mode, the global search query, and the last quiz result. Feature-specific data
 * (notices, results, ebooks, etc.) lives in their own screen-scoped Hilt ViewModels -- this one
 * only holds what genuinely needs to be shared across the whole navigation graph.
 */
@HiltViewModel
class AppViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    // ---------- Auth ----------
    private val _isLoggedIn = MutableStateFlow(authRepository.isLoggedIn)
    val isLoggedInFlow: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    val isLoggedIn: Boolean get() = _isLoggedIn.value

    private val _currentStudent = MutableStateFlow<Student?>(null)
    val currentStudent: StateFlow<Student?> = _currentStudent.asStateFlow()

    var selectedDepartment by mutableStateOf<String?>(null)
        private set

    var loginError by mutableStateOf<String?>(null)
        private set

    var isLoggingIn by mutableStateOf(false)
        private set

    init {
        viewModelScope.launch {
            authRepository.observeAuthState().collect { loggedIn ->
                _isLoggedIn.value = loggedIn
                if (loggedIn) refreshCurrentStudent() else _currentStudent.value = null
            }
        }
    }

    fun selectDepartment(name: String) {
        selectedDepartment = name
    }

    /** Real Firebase email/password sign-in. Returns true on success so the caller can navigate. */
    suspend fun login(email: String, password: String): Boolean {
        isLoggingIn = true
        loginError = null
        val result = authRepository.login(email, password)
        isLoggingIn = false
        return when (result) {
            is Resource.Success -> {
                refreshCurrentStudent()
                true
            }
            is Resource.Error -> {
                loginError = result.message
                false
            }
            Resource.Loading -> false
        }
    }

    private suspend fun refreshCurrentStudent() {
        when (val result = authRepository.fetchCurrentStudent()) {
            is Resource.Success -> _currentStudent.value = result.data
            else -> Unit
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
            _currentStudent.value = null
            selectedDepartment = null
        }
    }

    // ---------- Global Search ----------
    var searchQuery by mutableStateOf("")

    // ---------- Quiz score (read by GameScreen after a quiz finishes) ----------
    var lastQuizScore by mutableStateOf(0)
    var lastQuizCategory by mutableStateOf("")
}
