package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.CampusInfo
import com.dgmpi.app.data.model.Department
import com.dgmpi.app.data.model.FacilityItem
import com.dgmpi.app.data.model.GalleryImage
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeDoc
import com.dgmpi.app.data.remote.observeList
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.Flow
import javax.inject.Singleton

interface CampusRepository {
    fun observeCampusInfo(): Flow<Resource<CampusInfo?>>
    fun observeDepartments(): Flow<Resource<List<Department>>>
    fun observeFacilities(): Flow<Resource<List<FacilityItem>>>
    fun observeGallery(category: String? = null): Flow<Resource<List<GalleryImage>>>
}

@Singleton
class CampusRepositoryImpl @javax.inject.Inject constructor(
    private val firestore: FirebaseFirestore
) : CampusRepository {

    override fun observeCampusInfo(): Flow<Resource<CampusInfo?>> =
        firestore.collection(FirestorePaths.CAMPUS_INFO).document("current").observeDoc()

    override fun observeDepartments(): Flow<Resource<List<Department>>> =
        firestore.collection(FirestorePaths.DEPARTMENTS).orderBy("name").observeList()

    override fun observeFacilities(): Flow<Resource<List<FacilityItem>>> =
        firestore.collection(FirestorePaths.FACILITIES).observeList()

    override fun observeGallery(category: String?): Flow<Resource<List<GalleryImage>>> {
        var query: Query = firestore.collection(FirestorePaths.GALLERY)
            .orderBy("uploadedAtMillis", Query.Direction.DESCENDING)
        if (!category.isNullOrBlank()) {
            query = query.whereEqualTo("category", category)
        }
        return query.observeList()
    }
}
