package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.AdmissionInfo
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeDoc
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

interface AdmissionRepository {
    fun observeAdmissionInfo(): Flow<Resource<AdmissionInfo?>>
}

@Singleton
class AdmissionRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : AdmissionRepository {
    override fun observeAdmissionInfo(): Flow<Resource<AdmissionInfo?>> =
        firestore.collection(FirestorePaths.ADMISSION_INFO)
            .document("current")
            .observeDoc()
}
