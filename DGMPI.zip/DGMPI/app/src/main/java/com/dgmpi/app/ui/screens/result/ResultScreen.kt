package com.dgmpi.app.ui.screens.result

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.components.SectionCard
import com.dgmpi.app.ui.components.SectionTitle
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.ui.theme.SuccessGreen
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.ResultViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(onBack: () -> Unit, viewModel: ResultViewModel = hiltViewModel()) {
    var searchMode by remember { mutableStateOf("Roll") } // Roll or Registration
    var rollOrReg by remember { mutableStateOf("") }
    var semester by remember { mutableStateOf("") }
    val resultState by viewModel.result.collectAsState()

    Scaffold(
        topBar = { GradientHeader(title = "Result", subtitle = "Check semester results", onBack = onBack) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            SectionCard {
                SectionTitle("Search Result", Icons.Filled.Assessment)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = searchMode == "Roll", onClick = { searchMode = "Roll" }, label = { Text("By Roll") })
                    FilterChip(selected = searchMode == "Registration", onClick = { searchMode = "Registration" }, label = { Text("By Registration") })
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = rollOrReg,
                    onValueChange = { rollOrReg = it },
                    label = { Text(if (searchMode == "Roll") "Roll Number" else "Registration Number") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = semester,
                    onValueChange = { semester = it },
                    label = { Text("Semester (optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = {
                        if (searchMode == "Roll") viewModel.searchByRoll(rollOrReg, semester)
                        else viewModel.searchByRegistration(rollOrReg, semester)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Navy),
                    enabled = rollOrReg.isNotBlank()
                ) {
                    Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Search")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            when (val state = resultState) {
                null -> EmptyState("Enter your roll or registration number and tap Search to view your result.")
                is Resource.Loading -> Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Navy)
                }
                is Resource.Error -> Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(state.message, color = MaterialTheme.colorScheme.error)
                }
                is Resource.Success -> {
                    val record = state.data
                    SectionCard {
                        SectionTitle("Result Found")
                        ResultRow("Name", record.name)
                        ResultRow("Roll", record.roll)
                        ResultRow("Registration", record.registration)
                        ResultRow("Department", record.department)
                        ResultRow("Semester", record.semester)
                        ResultRow("GPA", record.gpa.toString())
                        ResultRow("CGPA", record.cgpa.toString())
                        ResultRow("Status", record.status)
                        if (record.subjectMarks.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Divider()
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Subject-wise Marks", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            record.subjectMarks.forEach { mark ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${mark.courseCode} — ${mark.courseName}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                    Text(mark.grade, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        if (record.resultPdfUrl.isNotBlank()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                            Button(onClick = { uriHandler.openUri(record.resultPdfUrl) }, colors = ButtonDefaults.buttonColors(containerColor = Navy)) {
                                Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Download Result PDF")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, fontWeight = FontWeight.Bold, color = if (label == "Status") SuccessGreen else Navy)
    }
}
