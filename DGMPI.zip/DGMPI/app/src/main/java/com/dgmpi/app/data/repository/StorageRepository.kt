package com.dgmpi.app.data.repository

import android.net.Uri
import com.dgmpi.app.util.Resource
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

interface StorageRepository {
    suspend fun uploadFile(folder: String, fileUri: Uri, fileName: String = UUID.randomUUID().toString()): Resource<String>
}

@Singleton
class StorageRepositoryImpl @Inject constructor(
    private val storage: FirebaseStorage
) : StorageRepository {
    override suspend fun uploadFile(folder: String, fileUri: Uri, fileName: String): Resource<String> = try {
        val ref = storage.reference.child("$folder/$fileName")
        ref.putFile(fileUri).await()
        val downloadUrl = ref.downloadUrl.await()
        Resource.Success(downloadUrl.toString())
    } catch (e: Exception) {
        Resource.Error(e.message ?: "Upload failed", e)
    }
}
