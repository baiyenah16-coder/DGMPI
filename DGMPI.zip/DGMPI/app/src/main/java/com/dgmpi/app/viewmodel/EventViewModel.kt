package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.EventItem
import com.dgmpi.app.data.repository.EventRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EventViewModel @Inject constructor(
    repository: EventRepository
) : ViewModel() {
    private val _events = MutableStateFlow<Resource<List<EventItem>>>(Resource.Loading)
    val events: StateFlow<Resource<List<EventItem>>> = _events.asStateFlow()

    init {
        viewModelScope.launch { repository.observeEvents().collect { _events.value = it } }
    }
}
