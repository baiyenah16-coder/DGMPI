package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.Ebook
import com.dgmpi.app.data.model.EbookCategory
import com.dgmpi.app.data.repository.EbookRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EbookViewModel @Inject constructor(
    private val repository: EbookRepository
) : ViewModel() {

    private val _ebooks = MutableStateFlow<Resource<List<Ebook>>>(Resource.Loading)
    val ebooks: StateFlow<Resource<List<Ebook>>> = _ebooks.asStateFlow()

    private val _categories = MutableStateFlow<Resource<List<EbookCategory>>>(Resource.Loading)
    val categories: StateFlow<Resource<List<EbookCategory>>> = _categories.asStateFlow()

    private val _bookmarkedIds = MutableStateFlow<Set<String>>(emptySet())
    val bookmarkedIds: StateFlow<Set<String>> = _bookmarkedIds.asStateFlow()

    private var currentStudentId: String? = null

    init {
        viewModelScope.launch { repository.observeEbooks().collect { _ebooks.value = it } }
        viewModelScope.launch { repository.observeCategories().collect { _categories.value = it } }
    }

    fun bindStudent(studentId: String) {
        if (currentStudentId == studentId) return
        currentStudentId = studentId
        viewModelScope.launch {
            repository.observeBookmarkedIds(studentId).collect { resource ->
                if (resource is Resource.Success) _bookmarkedIds.value = resource.data
            }
        }
    }

    fun toggleBookmark(ebookId: String) {
        val studentId = currentStudentId ?: return
        val isCurrentlyBookmarked = ebookId in _bookmarkedIds.value
        viewModelScope.launch {
            repository.toggleBookmark(studentId, ebookId, !isCurrentlyBookmarked)
        }
    }
}
