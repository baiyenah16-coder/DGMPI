package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.IssuedBook
import com.dgmpi.app.data.model.TaskItem
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeList
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

interface TaskRepository {
    fun observeTasks(studentId: String): Flow<Resource<List<TaskItem>>>
    suspend fun addTask(task: TaskItem): Resource<Unit>
    suspend fun toggleDone(taskId: String, isDone: Boolean): Resource<Unit>
    suspend fun deleteTask(taskId: String): Resource<Unit>
}

@Singleton
class TaskRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : TaskRepository {

    override fun observeTasks(studentId: String): Flow<Resource<List<TaskItem>>> =
        firestore.collection(FirestorePaths.TASKS)
            .whereEqualTo("studentId", studentId)
            .observeList()

    override suspend fun addTask(task: TaskItem): Resource<Unit> = try {
        firestore.collection(FirestorePaths.TASKS).add(task).await()
        Resource.Success(Unit)
    } catch (e: Exception) {
        Resource.Error(e.message ?: "Failed to add task", e)
    }

    override suspend fun toggleDone(taskId: String, isDone: Boolean): Resource<Unit> = try {
        firestore.collection(FirestorePaths.TASKS).document(taskId).update("isDone", isDone).await()
        Resource.Success(Unit)
    } catch (e: Exception) {
        Resource.Error(e.message ?: "Failed to update task", e)
    }

    override suspend fun deleteTask(taskId: String): Resource<Unit> = try {
        firestore.collection(FirestorePaths.TASKS).document(taskId).delete().await()
        Resource.Success(Unit)
    } catch (e: Exception) {
        Resource.Error(e.message ?: "Failed to delete task", e)
    }
}

interface LibraryRepository {
    fun observeIssuedBooks(studentId: String): Flow<Resource<List<IssuedBook>>>
}

@Singleton
class LibraryRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : LibraryRepository {
    override fun observeIssuedBooks(studentId: String): Flow<Resource<List<IssuedBook>>> =
        firestore.collection(FirestorePaths.ISSUED_BOOKS)
            .whereEqualTo("studentId", studentId)
            .observeList()
}
