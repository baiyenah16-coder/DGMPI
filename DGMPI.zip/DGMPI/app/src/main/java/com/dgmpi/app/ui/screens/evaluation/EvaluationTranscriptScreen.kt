package com.dgmpi.app.ui.screens.evaluation

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Grading
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.components.SectionCard
import com.dgmpi.app.ui.components.SectionTitle
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.AcademicRecordsViewModel
import com.dgmpi.app.viewmodel.AppViewModel

@Composable
fun EvaluationTranscriptScreen(appViewModel: AppViewModel, onBack: () -> Unit, viewModel: AcademicRecordsViewModel = hiltViewModel()) {
    val student by appViewModel.currentStudent.collectAsState()
    val evaluationsState by viewModel.evaluations.collectAsState()

    LaunchedEffect(student?.id) { student?.id?.let { viewModel.bindStudent(it) } }

    Scaffold(
        topBar = { GradientHeader(title = "Evaluation Transcript", subtitle = "Teacher assessment breakdown", onBack = onBack) }
    ) { padding ->
        when (val state = evaluationsState) {
            is Resource.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Navy)
            }
            is Resource.Error -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(state.message, color = MaterialTheme.colorScheme.error)
            }
            is Resource.Success -> {
                if (state.data.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(padding)) {
                        EmptyState("No evaluation records published yet.", modifier = Modifier.align(Alignment.Center))
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(state.data, key = { it.id }) { row ->
                            val total = row.assignment + row.quiz + row.mid + row.finalExam + row.practical
                            SectionCard {
                                SectionTitle(row.courseName, Icons.Filled.Grading)
                                MarkRow("Assignment", row.assignment, 10)
                                MarkRow("Quiz", row.quiz, 10)
                                MarkRow("Mid Term", row.mid, 30)
                                MarkRow("Final Exam", row.finalExam, 40)
                                MarkRow("Practical", row.practical, 20)
                                Divider()
                                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Total", fontWeight = FontWeight.Bold)
                                    Text("$total / 110", fontWeight = FontWeight.Bold, color = Navy)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(row.remarks, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MarkRow(label: String, value: Int, max: Int) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text("$value / $max", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
    }
}
