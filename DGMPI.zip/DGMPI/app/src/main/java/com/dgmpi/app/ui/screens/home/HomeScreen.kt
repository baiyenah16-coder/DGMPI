package com.dgmpi.app.ui.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.dgmpi.app.navigation.Routes
import com.dgmpi.app.navigation.searchPages
import com.dgmpi.app.ui.components.DrawerMenuEntry
import com.dgmpi.app.ui.components.publicMenuEntries
import com.dgmpi.app.ui.components.SectionCard
import com.dgmpi.app.ui.components.SectionTitle
import com.dgmpi.app.ui.theme.*
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.HomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onMenuClick: () -> Unit,
    onLoginClick: () -> Unit,
    onNavigate: (String) -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    var query by remember { mutableStateOf("") }
    val results = remember(query) { searchPages(query) }
    val homeContentState by viewModel.homeContent.collectAsState()
    val latestNoticesState by viewModel.latestNotices.collectAsState()

    Scaffold { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(NavyDark, Navy)))
                        .padding(horizontal = 20.dp, vertical = 20.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(48.dp).background(PureWhite, CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.School, contentDescription = "Logo", tint = Navy)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Dhaka Gov. Mohila\nPolytechnic Institute",
                            color = PureWhite,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Button(onClick = onLoginClick, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = NavyDark), shape = RoundedCornerShape(50)) {
                            Text("Login", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth().background(PureWhite, RoundedCornerShape(16.dp)),
                        placeholder = { Text("Search notices, admission, result...") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = PureWhite,
                            focusedContainerColor = PureWhite,
                            unfocusedBorderColor = androidx.compose.ui.graphics.Color.Transparent,
                            focusedBorderColor = Gold
                        )
                    )

                    AnimatedVisibility(visible = results.isNotEmpty()) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp).background(PureWhite, RoundedCornerShape(14.dp))
                        ) {
                            results.take(6).forEach { page ->
                                ListItem(
                                    headlineContent = { Text(page.title) },
                                    leadingContent = { Icon(Icons.Filled.ChevronRight, contentDescription = null) },
                                    modifier = Modifier.clickable {
                                        query = ""
                                        onNavigate(page.route)
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedButton(
                        onClick = onMenuClick,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = PureWhite),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PureWhite.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(50)
                    ) {
                        Icon(Icons.Filled.Menu, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Browse Menu")
                    }
                }
            }

            // Dynamic slider images from Admin Panel
            val content = (homeContentState as? Resource.Success)?.data
            if (content != null && content.sliderImages.isNotEmpty()) {
                item {
                    LazyRow(
                        modifier = Modifier.padding(vertical = 16.dp),
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(content.sliderImages, key = { it.id }) { slide ->
                            AsyncImage(
                                model = slide.imageUrl,
                                contentDescription = slide.caption,
                                modifier = Modifier.width(280.dp).height(140.dp)
                                    .background(Gold.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                                    .clickable { if (slide.linkRoute.isNotBlank()) onNavigate(slide.linkRoute) }
                            )
                        }
                    }
                }
            }

            if (content != null && content.principalMessage.isNotBlank()) {
                item {
                    Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                        SectionCard {
                            SectionTitle("Principal's Message", Icons.Filled.RecordVoiceOver)
                            Text(content.principalMessage, style = MaterialTheme.typography.bodyMedium, maxLines = 4)
                        }
                    }
                }
            }

            if (content != null && content.announcements.isNotEmpty()) {
                item {
                    Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                        SectionCard {
                            SectionTitle("Announcements", Icons.Filled.Campaign)
                            content.announcements.forEach { announcement ->
                                Row(modifier = Modifier.padding(vertical = 3.dp)) {
                                    Text("•  ", fontWeight = FontWeight.Bold, color = Navy)
                                    Text(announcement, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Column(modifier = Modifier.padding(20.dp)) {
                    SectionTitle("Quick Access", Icons.Filled.Widgets)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(publicMenuEntries) { entry ->
                            QuickMenuTile(entry) { onNavigate(entry.route) }
                        }
                    }
                }
            }

            item {
                Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                    SectionTitle("Latest Notices", Icons.Filled.Campaign)
                    when (val state = latestNoticesState) {
                        is Resource.Loading -> CircularProgressIndicator(color = Navy)
                        is Resource.Error -> Text(state.message, color = MaterialTheme.colorScheme.error)
                        is Resource.Success -> {
                            if (state.data.isEmpty()) {
                                Text("No notices published yet.", style = MaterialTheme.typography.bodyMedium)
                            } else {
                                state.data.forEach { notice ->
                                    SectionCard(modifier = Modifier.padding(bottom = 12.dp)) {
                                        Text(notice.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(notice.date, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(notice.description, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                                    }
                                }
                            }
                        }
                    }
                    TextButton(onClick = { onNavigate(Routes.NOTICE_BOARD) }) {
                        Text("View All Notices")
                        Icon(Icons.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun QuickMenuTile(entry: DrawerMenuEntry, onClick: () -> Unit) {
    Card(
        modifier = Modifier.width(96.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(modifier = Modifier.size(40.dp).background(Gold.copy(alpha = 0.15f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(entry.icon, contentDescription = null, tint = Navy)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(entry.label, style = MaterialTheme.typography.labelSmall, textAlign = androidx.compose.ui.text.style.TextAlign.Center, maxLines = 2)
        }
    }
}
