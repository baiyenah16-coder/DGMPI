package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.ExamRoutineItem
import com.dgmpi.app.data.model.SeatPlanItem
import com.dgmpi.app.data.repository.ExaminationRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ExaminationViewModel @Inject constructor(
    repository: ExaminationRepository
) : ViewModel() {
    private val _examRoutine = MutableStateFlow<Resource<List<ExamRoutineItem>>>(Resource.Loading)
    val examRoutine: StateFlow<Resource<List<ExamRoutineItem>>> = _examRoutine.asStateFlow()

    private val _seatPlan = MutableStateFlow<Resource<List<SeatPlanItem>>>(Resource.Loading)
    val seatPlan: StateFlow<Resource<List<SeatPlanItem>>> = _seatPlan.asStateFlow()

    init {
        viewModelScope.launch { repository.observeExamRoutine().collect { _examRoutine.value = it } }
        viewModelScope.launch { repository.observeSeatPlan().collect { _seatPlan.value = it } }
    }
}
