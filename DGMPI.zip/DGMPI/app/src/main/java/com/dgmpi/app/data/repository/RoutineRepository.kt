package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.RoutinePeriod
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeList
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

interface RoutineRepository {
    fun observeRoutine(department: String, semester: String): Flow<Resource<List<RoutinePeriod>>>
}

@Singleton
class RoutineRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : RoutineRepository {
    override fun observeRoutine(department: String, semester: String): Flow<Resource<List<RoutinePeriod>>> =
        firestore.collection(FirestorePaths.CLASS_ROUTINE)
            .whereEqualTo("department", department)
            .whereEqualTo("semester", semester)
            .observeList()
}
