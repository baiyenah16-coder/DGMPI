package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.Notice
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeList
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

interface NoticeRepository {
    fun observeNotices(): Flow<Resource<List<Notice>>>
}

@Singleton
class NoticeRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : NoticeRepository {
    override fun observeNotices(): Flow<Resource<List<Notice>>> =
        firestore.collection(FirestorePaths.NOTICES)
            .orderBy("isPinned", Query.Direction.DESCENDING)
            .orderBy("timestampMillis", Query.Direction.DESCENDING)
            .observeList()
}
