package com.dgmpi.app.util

/**
 * Wraps any async/remote value with its loading state so every screen can render
 * a consistent Loading / Error / Empty / Success UI without duplicating that logic.
 */
sealed class Resource<out T> {
    data object Loading : Resource<Nothing>()
    data class Success<T>(val data: T) : Resource<T>()
    data class Error(val message: String, val throwable: Throwable? = null) : Resource<Nothing>()

    val dataOrNull: T?
        get() = (this as? Success)?.data

    inline fun <R> map(transform: (T) -> R): Resource<R> = when (this) {
        is Loading -> Loading
        is Success -> Success(transform(data))
        is Error -> Error(message, throwable)
    }
}
