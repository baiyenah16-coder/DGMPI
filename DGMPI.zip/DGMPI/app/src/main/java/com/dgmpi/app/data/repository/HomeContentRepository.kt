package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.HomeContent
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeDoc
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

interface HomeContentRepository {
    fun observeHomeContent(): Flow<Resource<HomeContent?>>
}

@Singleton
class HomeContentRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : HomeContentRepository {
    override fun observeHomeContent(): Flow<Resource<HomeContent?>> =
        firestore.collection(FirestorePaths.HOME_CONTENT).document("current").observeDoc()
}
