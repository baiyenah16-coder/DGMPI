package com.dgmpi.app.ui.screens.attendance

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.components.SectionCard
import com.dgmpi.app.ui.components.SectionTitle
import com.dgmpi.app.ui.theme.ErrorRed
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.ui.theme.SuccessGreen
import com.dgmpi.app.ui.theme.WarningAmber
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.AcademicRecordsViewModel
import com.dgmpi.app.viewmodel.AppViewModel

@Composable
fun AttendanceScreen(appViewModel: AppViewModel, onBack: () -> Unit, viewModel: AcademicRecordsViewModel = hiltViewModel()) {
    val student by appViewModel.currentStudent.collectAsState()
    val attendanceState by viewModel.attendance.collectAsState()

    LaunchedEffect(student?.id) { student?.id?.let { viewModel.bindStudent(it) } }

    Scaffold(
        topBar = { GradientHeader(title = "Attendance", subtitle = "Semester attendance record", onBack = onBack) }
    ) { padding ->
        when (val state = attendanceState) {
            is Resource.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Navy)
            }
            is Resource.Error -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(state.message, color = MaterialTheme.colorScheme.error)
            }
            is Resource.Success -> {
                val records = state.data
                if (records.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(padding)) {
                        EmptyState("No attendance records available yet.", modifier = Modifier.align(Alignment.Center))
                    }
                } else {
                    val totalPresent = records.sumOf { it.present }
                    val totalAbsent = records.sumOf { it.absent }
                    val totalLate = records.sumOf { it.late }
                    val total = totalPresent + totalAbsent + totalLate
                    val percentage = if (total > 0) (totalPresent * 100 / total) else 0

                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            SectionCard {
                                SectionTitle("Overall Attendance", Icons.Filled.EventAvailable)
                                Text("$percentage%", style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold, color = Navy)
                                Spacer(modifier = Modifier.height(8.dp))
                                LinearProgressIndicator(
                                    progress = percentage / 100f,
                                    modifier = Modifier.fillMaxWidth().height(10.dp),
                                    color = if (percentage >= 75) SuccessGreen else WarningAmber
                                )
                                Spacer(modifier = Modifier.height(14.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    StatText("Present", totalPresent, SuccessGreen)
                                    StatText("Absent", totalAbsent, ErrorRed)
                                    StatText("Late", totalLate, WarningAmber)
                                }
                            }
                        }
                        item {
                            SectionCard {
                                SectionTitle("Monthly Breakdown")
                                records.forEach { m ->
                                    val monthTotal = m.present + m.absent + m.late
                                    val monthPct = if (monthTotal > 0) m.present * 100 / monthTotal else 0
                                    Column(modifier = Modifier.padding(vertical = 8.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(m.month, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                            Text("$monthPct%", style = MaterialTheme.typography.bodyMedium, color = Navy)
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        LinearProgressIndicator(
                                            progress = monthPct / 100f,
                                            modifier = Modifier.fillMaxWidth().height(6.dp),
                                            color = if (monthPct >= 75) SuccessGreen else WarningAmber
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatText(label: String, value: Int, color: androidx.compose.ui.graphics.Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("$value", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = color)
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}
