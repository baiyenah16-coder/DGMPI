package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.Notice
import com.dgmpi.app.data.repository.NoticeRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NoticeViewModel @Inject constructor(
    repository: NoticeRepository
) : ViewModel() {
    private val _notices = MutableStateFlow<Resource<List<Notice>>>(Resource.Loading)
    val notices: StateFlow<Resource<List<Notice>>> = _notices.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeNotices().collect { _notices.value = it }
        }
    }
}
