package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.BookmarkEntry
import com.dgmpi.app.data.model.Ebook
import com.dgmpi.app.data.model.EbookCategory
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeList
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

interface EbookRepository {
    fun observeEbooks(): Flow<Resource<List<Ebook>>>
    fun observeCategories(): Flow<Resource<List<EbookCategory>>>
    fun observeBookmarkedIds(studentId: String): Flow<Resource<Set<String>>>
    suspend fun toggleBookmark(studentId: String, ebookId: String, isBookmarked: Boolean)
}

@Singleton
class EbookRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : EbookRepository {

    override fun observeEbooks(): Flow<Resource<List<Ebook>>> =
        firestore.collection(FirestorePaths.EBOOKS).orderBy("title").observeList()

    override fun observeCategories(): Flow<Resource<List<EbookCategory>>> =
        firestore.collection(FirestorePaths.EBOOK_CATEGORIES).orderBy("name").observeList()

    override fun observeBookmarkedIds(studentId: String): Flow<Resource<Set<String>>> =
        firestore.collection("bookmarks")
            .whereEqualTo("studentId", studentId)
            .observeList<BookmarkEntry>()
            .map { resource -> resource.map { list -> list.map { it.ebookId }.toSet() } }

    override suspend fun toggleBookmark(studentId: String, ebookId: String, isBookmarked: Boolean) {
        val docId = "${studentId}_$ebookId"
        val ref = firestore.collection("bookmarks").document(docId)
        if (isBookmarked) {
            ref.set(BookmarkEntry(id = docId, studentId = studentId, ebookId = ebookId)).await()
        } else {
            ref.delete().await()
        }
    }
}
