package com.dgmpi.app.ui.screens.examination

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.components.SectionCard
import com.dgmpi.app.ui.components.SectionTitle
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.ExaminationViewModel

@Composable
fun ExaminationScreen(onBack: () -> Unit, viewModel: ExaminationViewModel = hiltViewModel()) {
    var tabIndex by remember { mutableStateOf(0) }
    val tabs = listOf("Routine", "Seat Plan", "Notices", "Guidelines")
    val examRoutineState by viewModel.examRoutine.collectAsState()
    val seatPlanState by viewModel.seatPlan.collectAsState()

    Scaffold(
        topBar = { GradientHeader(title = "Examination", subtitle = "Semester final", onBack = onBack) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = tabIndex, containerColor = MaterialTheme.colorScheme.surface, contentColor = Navy) {
                tabs.forEachIndexed { index, title ->
                    Tab(selected = tabIndex == index, onClick = { tabIndex = index }, text = { Text(title) })
                }
            }
            Column(modifier = Modifier.padding(16.dp)) {
                when (tabIndex) {
                    0 -> ResourceSection(examRoutineState, "No exam routine published yet.") { routine ->
                        SectionCard {
                            SectionTitle("Exam Routine", Icons.Filled.EditCalendar)
                            routine.forEach { item ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column {
                                        Text(item.subject, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                        Text("${item.date} • ${item.time}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text(item.room, color = Navy, fontWeight = FontWeight.Bold)
                                }
                                Divider()
                            }
                        }
                    }
                    1 -> ResourceSection(seatPlanState, "No seat plan published yet.") { seats ->
                        SectionCard {
                            SectionTitle("Seat Plan", Icons.Filled.EventSeat)
                            seats.forEach { item ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Roll: ${item.roll}", style = MaterialTheme.typography.bodyMedium)
                                    Text("${item.room} - Seat ${item.seatNo}", color = Navy, fontWeight = FontWeight.Bold)
                                }
                                Divider()
                            }
                        }
                    }
                    2 -> SectionCard {
                        SectionTitle("Exam Notices", Icons.Filled.Campaign)
                        Text("Check the Notice Board for the latest exam-related notices.", style = MaterialTheme.typography.bodyMedium)
                    }
                    3 -> SectionCard {
                        SectionTitle("Guidelines", Icons.Filled.Rule)
                        listOf(
                            "Bring your admit card and student ID to the exam hall.",
                            "Arrive at least 30 minutes before the exam starts.",
                            "Mobile phones and electronic devices are strictly prohibited.",
                            "Follow the seating arrangement as per the seat plan."
                        ).forEach {
                            Row(modifier = Modifier.padding(vertical = 4.dp)) {
                                Text("•  ", fontWeight = FontWeight.Bold, color = Navy)
                                Text(it, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun <T> ResourceSection(state: Resource<List<T>>, emptyMessage: String, content: @Composable (List<T>) -> Unit) {
    when (state) {
        is Resource.Loading -> Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Navy)
        }
        is Resource.Error -> Text(state.message, color = MaterialTheme.colorScheme.error)
        is Resource.Success -> if (state.data.isEmpty()) EmptyState(emptyMessage) else content(state.data)
    }
}
