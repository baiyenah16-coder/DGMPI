package com.dgmpi.app.di

import com.dgmpi.app.data.repository.*
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds @Singleton
    abstract fun bindAuthRepository(impl: AuthRepositoryImpl): AuthRepository

    @Binds @Singleton
    abstract fun bindStudentRepository(impl: StudentRepositoryImpl): StudentRepository

    @Binds @Singleton
    abstract fun bindTeacherRepository(impl: TeacherRepositoryImpl): TeacherRepository

    @Binds @Singleton
    abstract fun bindNoticeRepository(impl: NoticeRepositoryImpl): NoticeRepository

    @Binds @Singleton
    abstract fun bindAdmissionRepository(impl: AdmissionRepositoryImpl): AdmissionRepository

    @Binds @Singleton
    abstract fun bindResultRepository(impl: ResultRepositoryImpl): ResultRepository

    @Binds @Singleton
    abstract fun bindExaminationRepository(impl: ExaminationRepositoryImpl): ExaminationRepository

    @Binds @Singleton
    abstract fun bindEbookRepository(impl: EbookRepositoryImpl): EbookRepository

    @Binds @Singleton
    abstract fun bindQuizRepository(impl: QuizRepositoryImpl): QuizRepository

    @Binds @Singleton
    abstract fun bindCampusRepository(impl: CampusRepositoryImpl): CampusRepository

    @Binds @Singleton
    abstract fun bindHomeContentRepository(impl: HomeContentRepositoryImpl): HomeContentRepository

    @Binds @Singleton
    abstract fun bindEventRepository(impl: EventRepositoryImpl): EventRepository

    @Binds @Singleton
    abstract fun bindApplicationRepository(impl: ApplicationRepositoryImpl): ApplicationRepository

    @Binds @Singleton
    abstract fun bindAcademicRecordsRepository(impl: AcademicRecordsRepositoryImpl): AcademicRecordsRepository

    @Binds @Singleton
    abstract fun bindTaskRepository(impl: TaskRepositoryImpl): TaskRepository

    @Binds @Singleton
    abstract fun bindLibraryRepository(impl: LibraryRepositoryImpl): LibraryRepository

    @Binds @Singleton
    abstract fun bindRoutineRepository(impl: RoutineRepositoryImpl): RoutineRepository

    @Binds @Singleton
    abstract fun bindStorageRepository(impl: StorageRepositoryImpl): StorageRepository

    @Binds @Singleton
    abstract fun bindSettingsRepository(impl: SettingsRepositoryImpl): SettingsRepository
}
