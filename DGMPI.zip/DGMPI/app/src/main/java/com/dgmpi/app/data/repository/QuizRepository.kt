package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.LeaderboardEntry
import com.dgmpi.app.data.model.QuizCategory
import com.dgmpi.app.data.model.QuizQuestion
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeList
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

interface QuizRepository {
    fun observeQuizCategories(): Flow<Resource<List<QuizCategory>>>
    fun observeQuestions(categoryId: String): Flow<Resource<List<QuizQuestion>>>
    fun observeLeaderboard(): Flow<Resource<List<LeaderboardEntry>>>
    suspend fun submitScore(studentId: String, name: String, score: Int, badge: String)
}

@Singleton
class QuizRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : QuizRepository {

    override fun observeQuizCategories(): Flow<Resource<List<QuizCategory>>> =
        firestore.collection(FirestorePaths.QUIZ_CATEGORIES).observeList()

    override fun observeQuestions(categoryId: String): Flow<Resource<List<QuizQuestion>>> =
        firestore.collection(FirestorePaths.QUIZ_QUESTIONS)
            .whereEqualTo("categoryId", categoryId)
            .observeList()

    override fun observeLeaderboard(): Flow<Resource<List<LeaderboardEntry>>> =
        firestore.collection(FirestorePaths.LEADERBOARD)
            .orderBy("score", Query.Direction.DESCENDING)
            .limit(20)
            .observeList()

    override suspend fun submitScore(studentId: String, name: String, score: Int, badge: String) {
        firestore.collection(FirestorePaths.LEADERBOARD)
            .document(studentId)
            .set(
                LeaderboardEntry(id = studentId, rank = 0, name = name, score = score, badge = badge, studentId = studentId)
            )
            .await()
    }
}
