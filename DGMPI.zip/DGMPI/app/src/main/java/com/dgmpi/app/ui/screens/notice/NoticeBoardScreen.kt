package com.dgmpi.app.ui.screens.notice

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.dgmpi.app.data.model.Notice
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GoldOutlineBadge
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.components.SectionCard
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.NoticeViewModel

@Composable
fun NoticeBoardScreen(onBack: () -> Unit, viewModel: NoticeViewModel = hiltViewModel()) {
    val noticesState by viewModel.notices.collectAsState()

    Scaffold(
        topBar = {
            val count = (noticesState as? Resource.Success)?.data?.size ?: 0
            GradientHeader(title = "Notice Board", subtitle = "$count active notices", onBack = onBack)
        }
    ) { padding ->
        when (val state = noticesState) {
            is Resource.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Navy)
            }
            is Resource.Error -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(state.message, color = MaterialTheme.colorScheme.error)
            }
            is Resource.Success -> {
                if (state.data.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(padding)) {
                        EmptyState("No notices have been published yet.", modifier = Modifier.align(Alignment.Center))
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(state.data, key = { it.id }) { notice -> NoticeCard(notice) }
                    }
                }
            }
        }
    }
}

@Composable
private fun NoticeCard(notice: Notice) {
    SectionCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(notice.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            GoldOutlineBadge(notice.category)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.CalendarMonth, contentDescription = null, tint = Navy, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(notice.date, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(notice.description, style = MaterialTheme.typography.bodyMedium)
        if (notice.attachmentUrl.isNotBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
            OutlinedButton(onClick = { uriHandler.openUri(notice.attachmentUrl) }) {
                Icon(Icons.Filled.AttachFile, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("View Attachment")
            }
        }
    }
}
