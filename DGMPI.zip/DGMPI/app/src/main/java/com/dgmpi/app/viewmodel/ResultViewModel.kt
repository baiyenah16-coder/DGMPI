package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.ResultRecord
import com.dgmpi.app.data.repository.ResultRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ResultViewModel @Inject constructor(
    private val repository: ResultRepository
) : ViewModel() {

    private val _result = MutableStateFlow<Resource<ResultRecord>?>(null)
    val result: StateFlow<Resource<ResultRecord>?> = _result.asStateFlow()

    fun searchByRoll(roll: String, semester: String) {
        if (roll.isBlank()) return
        _result.value = Resource.Loading
        viewModelScope.launch {
            _result.value = repository.searchByRoll(roll, semester)
        }
    }

    fun searchByRegistration(registration: String, semester: String) {
        if (registration.isBlank()) return
        _result.value = Resource.Loading
        viewModelScope.launch {
            _result.value = repository.searchByRegistration(registration, semester)
        }
    }

    fun clear() {
        _result.value = null
    }
}
