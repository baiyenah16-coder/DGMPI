package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.ApplicationSubmission
import com.dgmpi.app.data.model.ApplicationType
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.repository.ApplicationRepository
import com.dgmpi.app.data.repository.StorageRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ApplicationViewModel @Inject constructor(
    private val repository: ApplicationRepository,
    private val storageRepository: StorageRepository
) : ViewModel() {

    private val _types = MutableStateFlow<Resource<List<ApplicationType>>>(Resource.Loading)
    val types: StateFlow<Resource<List<ApplicationType>>> = _types.asStateFlow()

    private val _mySubmissions = MutableStateFlow<Resource<List<ApplicationSubmission>>>(Resource.Loading)
    val mySubmissions: StateFlow<Resource<List<ApplicationSubmission>>> = _mySubmissions.asStateFlow()

    private val _submitState = MutableStateFlow<Resource<Unit>?>(null)
    val submitState: StateFlow<Resource<Unit>?> = _submitState.asStateFlow()

    private var boundId: String? = null

    init {
        viewModelScope.launch { repository.observeApplicationTypes().collect { _types.value = it } }
    }

    fun bindStudent(studentId: String) {
        if (boundId == studentId) return
        boundId = studentId
        viewModelScope.launch {
            repository.observeMySubmissions(studentId).collect { _mySubmissions.value = it }
        }
    }

    fun submit(
        studentId: String,
        studentName: String,
        type: ApplicationType,
        reason: String,
        attachmentUri: android.net.Uri?
    ) {
        viewModelScope.launch {
            _submitState.value = Resource.Loading
            var attachmentUrl = ""
            if (attachmentUri != null) {
                when (val uploadResult = storageRepository.uploadFile(FirestorePaths.STORAGE_NOTICE_ATTACHMENTS, attachmentUri)) {
                    is Resource.Success -> attachmentUrl = uploadResult.data
                    is Resource.Error -> {
                        _submitState.value = uploadResult
                        return@launch
                    }
                    Resource.Loading -> Unit
                }
            }
            val submission = ApplicationSubmission(
                studentId = studentId,
                studentName = studentName,
                typeId = type.id,
                typeTitle = type.title,
                reason = reason,
                attachmentUrl = attachmentUrl,
                submittedAtMillis = System.currentTimeMillis()
            )
            _submitState.value = repository.submit(submission)
        }
    }

    fun clearSubmitState() {
        _submitState.value = null
    }
}
