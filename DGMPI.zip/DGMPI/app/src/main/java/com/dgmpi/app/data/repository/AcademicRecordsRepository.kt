package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.CaseHistoryItem
import com.dgmpi.app.data.model.EvaluationRow
import com.dgmpi.app.data.model.MonthlyAttendance
import com.dgmpi.app.data.model.TranscriptRow
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeList
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

interface AcademicRecordsRepository {
    fun observeAttendance(studentId: String): Flow<Resource<List<MonthlyAttendance>>>
    fun observeCaseHistory(studentId: String): Flow<Resource<List<CaseHistoryItem>>>
    fun observeEvaluations(studentId: String): Flow<Resource<List<EvaluationRow>>>
    fun observeTranscript(studentId: String): Flow<Resource<List<TranscriptRow>>>
}

@Singleton
class AcademicRecordsRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : AcademicRecordsRepository {

    override fun observeAttendance(studentId: String): Flow<Resource<List<MonthlyAttendance>>> =
        firestore.collection(FirestorePaths.ATTENDANCE)
            .whereEqualTo("studentId", studentId)
            .observeList()

    override fun observeCaseHistory(studentId: String): Flow<Resource<List<CaseHistoryItem>>> =
        firestore.collection(FirestorePaths.CASE_HISTORY)
            .whereEqualTo("studentId", studentId)
            .observeList()

    override fun observeEvaluations(studentId: String): Flow<Resource<List<EvaluationRow>>> =
        firestore.collection(FirestorePaths.EVALUATIONS)
            .whereEqualTo("studentId", studentId)
            .observeList()

    override fun observeTranscript(studentId: String): Flow<Resource<List<TranscriptRow>>> =
        firestore.collection("transcripts")
            .whereEqualTo("studentId", studentId)
            .orderBy("semester")
            .observeList()
}
