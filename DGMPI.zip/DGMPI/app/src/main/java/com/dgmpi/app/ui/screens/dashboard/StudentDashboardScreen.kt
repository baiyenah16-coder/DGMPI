package com.dgmpi.app.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.dgmpi.app.data.MockData
import com.dgmpi.app.ui.components.*
import com.dgmpi.app.ui.theme.*
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.AppViewModel
import com.dgmpi.app.viewmodel.DashboardViewModel

@Composable
fun StudentDashboardScreen(
    appViewModel: AppViewModel,
    onMenuClick: () -> Unit,
    onNavigate: (String) -> Unit,
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val student by appViewModel.currentStudent.collectAsState()
    val teachersState by viewModel.teachers.collectAsState()
    val latestNoticeState by viewModel.latestNotice.collectAsState()
    val routineState by viewModel.routine.collectAsState()

    LaunchedEffect(student?.department, student?.semester) {
        val s = student
        if (s != null) viewModel.bindStudent(s.department, s.semester)
    }

    Scaffold { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(NavyDark, Navy)))
                        .padding(horizontal = 20.dp, vertical = 20.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onMenuClick) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = PureWhite)
                        }
                        Box(modifier = Modifier.size(44.dp).background(PureWhite, CircleShape), contentAlignment = Alignment.Center) {
                            if (!student?.photoUrl.isNullOrBlank()) {
                                AsyncImage(model = student?.photoUrl, contentDescription = "Student photo", modifier = Modifier.size(44.dp))
                            } else {
                                Icon(Icons.Filled.Person, contentDescription = "Student photo", tint = Navy)
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(student?.name ?: "", color = PureWhite, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(student?.department ?: "", color = PureWhite.copy(alpha = 0.75f), style = MaterialTheme.typography.labelSmall)
                        }
                        IconButton(onClick = { /* notifications handled by system tray via FCM */ }) {
                            Icon(Icons.Filled.Notifications, contentDescription = "Notifications", tint = PureWhite)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatChip("Semester", student?.semester?.take(10) ?: "-", modifier = Modifier.weight(1f))
                        StatChip("Session", student?.session ?: "-", modifier = Modifier.weight(1f))
                        StatChip("Roll", student?.roll ?: "-", modifier = Modifier.weight(1f))
                    }
                }
            }

            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionTitle("Quick Access", Icons.Filled.Widgets)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(MockData.quickAccess) { qa ->
                            Card(
                                modifier = Modifier.width(90.dp),
                                shape = RoundedCornerShape(16.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                onClick = { onNavigate(qa.route) }
                            ) {
                                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    IconBadge(IconMapper.get(qa.icon))
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(qa.title, style = MaterialTheme.typography.labelSmall, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    SectionCard {
                        SectionTitle("Latest Notice", Icons.Filled.Campaign)
                        when (val state = latestNoticeState) {
                            is Resource.Loading -> CircularProgressIndicator(color = Navy)
                            is Resource.Error -> Text(state.message, color = MaterialTheme.colorScheme.error)
                            is Resource.Success -> {
                                val n = state.data
                                if (n == null) {
                                    Text("No notices yet.", style = MaterialTheme.typography.bodyMedium)
                                } else {
                                    Text(n.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    Text(n.date, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    SectionCard {
                        SectionTitle("Today's Classes", Icons.Filled.Schedule)
                        when (val state = routineState) {
                            is Resource.Loading -> CircularProgressIndicator(color = Navy)
                            is Resource.Error -> Text(state.message, color = MaterialTheme.colorScheme.error)
                            is Resource.Success -> {
                                if (state.data.isEmpty()) {
                                    Text("No routine published for your department/semester yet.", style = MaterialTheme.typography.bodyMedium)
                                } else {
                                    state.data.forEach { period ->
                                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Column {
                                                Text(period.subject, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                                Text(period.teacher, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            Text(period.time, color = Navy, style = MaterialTheme.typography.labelMedium)
                                        }
                                        Divider()
                                    }
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    SectionCard {
                        SectionTitle("Teacher Directory", Icons.Filled.Groups)
                        when (val state = teachersState) {
                            is Resource.Loading -> CircularProgressIndicator(color = Navy)
                            is Resource.Error -> Text(state.message, color = MaterialTheme.colorScheme.error)
                            is Resource.Success -> state.data.take(3).forEach { t ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    IconBadge(Icons.Filled.Person, backgroundColor = Navy.copy(alpha = 0.08f))
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(t.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                        Text("${t.designation} • ${t.department}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
