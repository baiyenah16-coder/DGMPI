package com.dgmpi.app.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Central place mapping a plain-string icon key (used inside mock data models
 * so they stay UI-framework agnostic) to an actual Material ImageVector.
 */
object IconMapper {
    fun get(key: String): ImageVector = when (key) {
        "book" -> Icons.Filled.MenuBook
        "computer" -> Icons.Filled.Computer
        "science" -> Icons.Filled.Science
        "home" -> Icons.Filled.Home
        "sports" -> Icons.Filled.SportsBasketball
        "medical" -> Icons.Filled.LocalHospital
        "architecture" -> Icons.Filled.Architecture
        "bolt" -> Icons.Filled.Bolt
        "memory" -> Icons.Filled.Memory
        "hotel" -> Icons.Filled.Hotel
        "calculate" -> Icons.Filled.Calculate
        "language" -> Icons.Filled.Language
        "code" -> Icons.Filled.Code
        "hub" -> Icons.Filled.Hub
        "storage" -> Icons.Filled.Storage
        "coffee" -> Icons.Filled.Coffee
        "web" -> Icons.Filled.Web
        "public" -> Icons.Filled.Public
        "school" -> Icons.Filled.School
        "event_busy" -> Icons.Filled.EventBusy
        "workspace_premium" -> Icons.Filled.WorkspacePremium
        "description" -> Icons.Filled.Description
        "logout" -> Icons.Filled.ExitToApp
        "upload_file" -> Icons.Filled.UploadFile
        "event_available" -> Icons.Filled.EventAvailable
        "badge" -> Icons.Filled.Badge
        "menu_book" -> Icons.Filled.MenuBook
        else -> Icons.Filled.Circle
    }
}
