package com.dgmpi.app.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette: Navy, White, Gold
val NavyDark = Color(0xFF0B1E3D)
val Navy = Color(0xFF12305C)
val NavyLight = Color(0xFF1E4079)
val Gold = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF2D57E)
val OffWhite = Color(0xFFF7F8FA)
val PureWhite = Color(0xFFFFFFFF)
val SlateText = Color(0xFF1C2733)
val MutedText = Color(0xFF6B7684)
val SuccessGreen = Color(0xFF2E9E5B)
val WarningAmber = Color(0xFFE0A426)
val ErrorRed = Color(0xFFD64545)
val CardShadow = Color(0x1A0B1E3D)

// Dark theme surface tones
val DarkSurface = Color(0xFF10192B)
val DarkSurfaceVariant = Color(0xFF1A2740)
val DarkOnSurface = Color(0xFFE7EAF0)
