package com.dgmpi.app.data

import com.dgmpi.app.data.model.QuickAccessItem

/**
 * All real content now comes from Firestore via the repository layer (see
 * data/repository/). The only thing left here is a small set of static
 * Quick Access shortcuts on the Student Dashboard -- these are just UI
 * navigation entries, not app content, so they don't need to live in Firestore.
 */
object MockData {
    val quickAccess = listOf(
        QuickAccessItem(id = "qa1", title = "Transcript", icon = "description", route = "transcript"),
        QuickAccessItem(id = "qa2", title = "Attendance", icon = "event_available", route = "attendance"),
        QuickAccessItem(id = "qa3", title = "ID Card", icon = "badge", route = "id_card"),
        QuickAccessItem(id = "qa4", title = "Library", icon = "menu_book", route = "library")
    )
}
