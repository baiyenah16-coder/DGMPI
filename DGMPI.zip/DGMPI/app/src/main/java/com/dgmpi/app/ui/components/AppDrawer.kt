package com.dgmpi.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dgmpi.app.navigation.Routes
import com.dgmpi.app.ui.theme.*

data class DrawerMenuEntry(val label: String, val icon: ImageVector, val route: String)

val publicMenuEntries = listOf(
    DrawerMenuEntry("Our Campus", Icons.Filled.Domain, Routes.CAMPUS),
    DrawerMenuEntry("Notice Board", Icons.Filled.Campaign, Routes.NOTICE_BOARD),
    DrawerMenuEntry("Admission", Icons.Filled.HowToReg, Routes.ADMISSION),
    DrawerMenuEntry("Result", Icons.Filled.Assessment, Routes.RESULT),
    DrawerMenuEntry("Examination", Icons.Filled.EditNote, Routes.EXAMINATION),
    DrawerMenuEntry("eBook", Icons.Filled.MenuBook, Routes.EBOOK),
    DrawerMenuEntry("Game", Icons.Filled.SportsEsports, Routes.GAME),
    DrawerMenuEntry("Gallery", Icons.Filled.PhotoLibrary, Routes.GALLERY),
    DrawerMenuEntry("Events", Icons.Filled.Event, Routes.EVENTS)
)

val studentMenuEntries = listOf(
    DrawerMenuEntry("Dashboard", Icons.Filled.Dashboard, Routes.DASHBOARD),
    DrawerMenuEntry("Student Account", Icons.Filled.AccountBalanceWallet, Routes.PROFILE),
    DrawerMenuEntry("Profile", Icons.Filled.Person, Routes.PROFILE),
    DrawerMenuEntry("Transcript", Icons.Filled.Description, Routes.TRANSCRIPT),
    DrawerMenuEntry("Attendance", Icons.Filled.EventAvailable, Routes.ATTENDANCE),
    DrawerMenuEntry("Case History", Icons.Filled.History, Routes.CASE_HISTORY),
    DrawerMenuEntry("ID Card", Icons.Filled.Badge, Routes.ID_CARD),
    DrawerMenuEntry("Evaluation Transcript", Icons.Filled.Grading, Routes.EVALUATION),
    DrawerMenuEntry("Application", Icons.Filled.Article, Routes.APPLICATION),
    DrawerMenuEntry("Diary & Task", Icons.Filled.EventNote, Routes.DIARY_TASK),
    DrawerMenuEntry("Library", Icons.Filled.LocalLibrary, Routes.LIBRARY),
    DrawerMenuEntry("Settings", Icons.Filled.Settings, Routes.SETTINGS)
)

@Composable
fun AppDrawerContent(
    entries: List<DrawerMenuEntry>,
    currentRoute: String?,
    onItemClick: (DrawerMenuEntry) -> Unit,
    onLogout: (() -> Unit)? = null
) {
    ModalDrawerSheet {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(NavyDark, Navy)))
                .padding(24.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(PureWhite, shape = MaterialTheme.shapes.medium),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.School, contentDescription = null, tint = Navy)
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                "Dhaka Gov. Mohila\nPolytechnic Institute",
                color = PureWhite,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        entries.forEach { entry ->
            NavigationDrawerItem(
                label = { Text(entry.label) },
                icon = { Icon(entry.icon, contentDescription = null) },
                selected = currentRoute == entry.route,
                onClick = { onItemClick(entry) },
                colors = NavigationDrawerItemDefaults.colors(
                    selectedContainerColor = Gold.copy(alpha = 0.18f),
                    selectedIconColor = Navy,
                    selectedTextColor = Navy
                ),
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
            )
        }
        if (onLogout != null) {
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            NavigationDrawerItem(
                label = { Text("Logout") },
                icon = { Icon(Icons.Filled.ExitToApp, contentDescription = null) },
                selected = false,
                onClick = onLogout,
                colors = NavigationDrawerItemDefaults.colors(
                    unselectedIconColor = ErrorRed,
                    unselectedTextColor = ErrorRed
                ),
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
    }
}
