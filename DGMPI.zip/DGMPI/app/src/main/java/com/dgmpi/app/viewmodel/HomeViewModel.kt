package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.HomeContent
import com.dgmpi.app.data.model.Notice
import com.dgmpi.app.data.repository.HomeContentRepository
import com.dgmpi.app.data.repository.NoticeRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    homeContentRepository: HomeContentRepository,
    noticeRepository: NoticeRepository
) : ViewModel() {

    private val _homeContent = MutableStateFlow<Resource<HomeContent?>>(Resource.Loading)
    val homeContent: StateFlow<Resource<HomeContent?>> = _homeContent.asStateFlow()

    private val _latestNotices = MutableStateFlow<Resource<List<Notice>>>(Resource.Loading)
    val latestNotices: StateFlow<Resource<List<Notice>>> = _latestNotices.asStateFlow()

    init {
        viewModelScope.launch {
            homeContentRepository.observeHomeContent().collect { _homeContent.value = it }
        }
        viewModelScope.launch {
            noticeRepository.observeNotices().collect { resource ->
                _latestNotices.value = resource.map { it.take(3) }
            }
        }
    }
}
