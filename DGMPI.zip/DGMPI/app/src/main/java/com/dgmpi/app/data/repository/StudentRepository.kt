package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.Student
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeList
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

interface StudentRepository {
    fun observeStudent(studentId: String): Flow<Resource<Student?>>
    fun observeStudentByAuthUid(authUid: String): Flow<Resource<Student?>>
}

@Singleton
class StudentRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : StudentRepository {

    override fun observeStudent(studentId: String): Flow<Resource<Student?>> =
        firestore.collection(FirestorePaths.STUDENTS)
            .whereEqualTo(com.google.firebase.firestore.FieldPath.documentId(), studentId)
            .observeList<Student>()
            .map { resource -> resource.map { it.firstOrNull() } }

    override fun observeStudentByAuthUid(authUid: String): Flow<Resource<Student?>> =
        firestore.collection(FirestorePaths.STUDENTS)
            .whereEqualTo("authUid", authUid)
            .limit(1)
            .observeList<Student>()
            .map { resource -> resource.map { it.firstOrNull() } }
}
