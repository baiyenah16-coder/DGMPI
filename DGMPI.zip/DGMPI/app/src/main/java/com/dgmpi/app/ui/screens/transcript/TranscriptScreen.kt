package com.dgmpi.app.ui.screens.transcript

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.components.SectionCard
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.ui.theme.SuccessGreen
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.AcademicRecordsViewModel
import com.dgmpi.app.viewmodel.AppViewModel

@Composable
fun TranscriptScreen(appViewModel: AppViewModel, onBack: () -> Unit, viewModel: AcademicRecordsViewModel = hiltViewModel()) {
    val student by appViewModel.currentStudent.collectAsState()
    val transcriptState by viewModel.transcript.collectAsState()

    LaunchedEffect(student?.id) { student?.id?.let { viewModel.bindStudent(it) } }

    Scaffold(
        topBar = { GradientHeader(title = "Transcript", subtitle = "Academic performance record", onBack = onBack) }
    ) { padding ->
        when (val state = transcriptState) {
            is Resource.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Navy)
            }
            is Resource.Error -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(state.message, color = MaterialTheme.colorScheme.error)
            }
            is Resource.Success -> {
                val rows = state.data
                if (rows.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(padding)) {
                        EmptyState("No transcript records published yet.", modifier = Modifier.align(Alignment.Center))
                    }
                } else {
                    val cgpa = rows.map { it.gpa }.average()
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            SectionCard {
                                Column {
                                    Text("Cumulative GPA", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(String.format("%.2f", cgpa), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Navy)
                                }
                            }
                        }
                        items(rows.groupBy { it.semester }.toList()) { (semester, semRows) ->
                            SectionCard {
                                Text("$semester Semester", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth()) {
                                    HeaderCell("Course", 2.2f)
                                    HeaderCell("Credit", 0.8f)
                                    HeaderCell("Grade", 0.8f)
                                    HeaderCell("GPA", 0.8f)
                                }
                                Divider()
                                semRows.forEach { row ->
                                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                                        Column(modifier = Modifier.weight(2.2f)) {
                                            Text(row.courseCode, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(row.courseName, style = MaterialTheme.typography.bodyMedium)
                                        }
                                        Cell("${row.credit}", 0.8f)
                                        Cell(row.grade, 0.8f, color = SuccessGreen)
                                        Cell("${row.gpa}", 0.8f)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.HeaderCell(text: String, weight: Float) {
    Text(text, modifier = Modifier.weight(weight), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = Navy)
}

@Composable
private fun RowScope.Cell(text: String, weight: Float, color: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.Unspecified) {
    Text(text, modifier = Modifier.weight(weight), style = MaterialTheme.typography.bodyMedium, color = color)
}
