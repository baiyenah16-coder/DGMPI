package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.EventItem
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeList
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

interface EventRepository {
    fun observeEvents(): Flow<Resource<List<EventItem>>>
}

@Singleton
class EventRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : EventRepository {
    override fun observeEvents(): Flow<Resource<List<EventItem>>> =
        firestore.collection(FirestorePaths.EVENTS).orderBy("date").observeList()
}
