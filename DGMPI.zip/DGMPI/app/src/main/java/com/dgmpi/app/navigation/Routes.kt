package com.dgmpi.app.navigation

object Routes {
    // Public
    const val SPLASH = "splash"
    const val HOME = "home"
    const val CAMPUS = "campus"
    const val NOTICE_BOARD = "notice_board"
    const val ADMISSION = "admission"
    const val RESULT = "result"
    const val EXAMINATION = "examination"
    const val EBOOK = "ebook"
    const val GAME = "game"
    const val GAME_QUIZ = "game_quiz/{categoryId}"
    fun gameQuiz(categoryId: String) = "game_quiz/$categoryId"
    const val GALLERY = "gallery"
    const val EVENTS = "events"
    const val SETTINGS = "settings"

    // Login
    const val DEPARTMENT_SELECTION = "department_selection"
    const val LOGIN = "login/{department}"
    fun login(department: String) = "login/$department"

    // Student area
    const val DASHBOARD = "dashboard"
    const val PROFILE = "profile"
    const val TRANSCRIPT = "transcript"
    const val ATTENDANCE = "attendance"
    const val CASE_HISTORY = "case_history"
    const val ID_CARD = "id_card"
    const val EVALUATION = "evaluation"
    const val APPLICATION = "application"
    const val DIARY_TASK = "diary_task"
    const val LIBRARY = "library"
}
