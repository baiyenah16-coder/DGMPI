package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.ExamRoutineItem
import com.dgmpi.app.data.model.SeatPlanItem
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.observeList
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

interface ExaminationRepository {
    fun observeExamRoutine(): Flow<Resource<List<ExamRoutineItem>>>
    fun observeSeatPlan(): Flow<Resource<List<SeatPlanItem>>>
}

@Singleton
class ExaminationRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : ExaminationRepository {
    override fun observeExamRoutine(): Flow<Resource<List<ExamRoutineItem>>> =
        firestore.collection(FirestorePaths.EXAM_ROUTINE).orderBy("date").observeList()

    override fun observeSeatPlan(): Flow<Resource<List<SeatPlanItem>>> =
        firestore.collection(FirestorePaths.SEAT_PLAN).observeList()
}
