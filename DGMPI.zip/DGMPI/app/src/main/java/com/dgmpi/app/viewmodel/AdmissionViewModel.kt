package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.AdmissionInfo
import com.dgmpi.app.data.repository.AdmissionRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AdmissionViewModel @Inject constructor(
    repository: AdmissionRepository
) : ViewModel() {
    private val _admissionInfo = MutableStateFlow<Resource<AdmissionInfo?>>(Resource.Loading)
    val admissionInfo: StateFlow<Resource<AdmissionInfo?>> = _admissionInfo.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeAdmissionInfo().collect { _admissionInfo.value = it }
        }
    }
}
