package com.dgmpi.app.data.model

import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.PropertyName

// ---------- Institute / Campus ----------
data class Department(
    @DocumentId val id: String = "",
    val name: String = "",
    val shortName: String = "",
    val headOfDept: String = "",
    val description: String = "",
    val iconUrl: String = ""
)

data class GalleryImage(
    @DocumentId val id: String = "",
    val caption: String = "",
    val imageUrl: String = "",
    val category: String = "Campus", // Campus, Classroom, Lab, Library, Hostel, Events, Convocation, Sports, Cultural Program
    val uploadedAtMillis: Long = 0L
)

data class FacilityItem(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val icon: String = "" // maps to a Material icon key in IconMapper
)

/** Single "current" document holding editable Our Campus page content. */
data class CampusInfo(
    val bannerImageUrl: String = "",
    val introduction: String = "",
    val principalMessage: String = "",
    val principalName: String = "Principal, DGMPI",
    val principalPhotoUrl: String = "",
    val vision: String = "",
    val mission: String = "",
    val address: String = "",
    val phone: String = "",
    val email: String = "",
    val mapLatitude: Double = 0.0,
    val mapLongitude: Double = 0.0,
    // "At a Glance" stat tiles, e.g. "Departments" -> "7"
    val atAGlance: Map<String, String> = emptyMap()
)

// ---------- Notice Board ----------
data class Notice(
    @DocumentId val id: String = "",
    val title: String = "",
    val date: String = "",
    val timestampMillis: Long = 0L,
    val description: String = "",
    val category: String = "General",
    val attachmentUrl: String = "",
    val imageUrl: String = "",
    val isPinned: Boolean = false
)

// ---------- Admission ----------
data class FaqItem(
    @DocumentId val id: String = "",
    val question: String = "",
    val answer: String = ""
)

data class ImportantDate(
    @DocumentId val id: String = "",
    val label: String = "",
    val date: String = ""
)

/** Single "current" document for the whole Admission page. */
data class AdmissionInfo(
    val circularText: String = "",
    val circularPdfUrl: String = "",
    val eligibility: List<String> = emptyList(),
    val requiredDocuments: List<String> = emptyList(),
    val applicationSteps: List<String> = emptyList(),
    val fees: Map<String, String> = emptyMap(),
    val importantDates: List<ImportantDate> = emptyList(),
    val faqs: List<FaqItem> = emptyList()
)

// ---------- Result ----------
data class SubjectMark(
    val courseCode: String = "",
    val courseName: String = "",
    val credit: Double = 0.0,
    val grade: String = "",
    val gpa: Double = 0.0
)

data class ResultRecord(
    @DocumentId val id: String = "",
    val roll: String = "",
    val registration: String = "",
    val name: String = "",
    val department: String = "",
    val semester: String = "",
    val gpa: Double = 0.0,
    val cgpa: Double = 0.0,
    val status: String = "",
    val subjectMarks: List<SubjectMark> = emptyList(),
    val resultPdfUrl: String = "",
    val published: Boolean = true
)

// ---------- Examination ----------
data class ExamRoutineItem(
    @DocumentId val id: String = "",
    val subject: String = "",
    val date: String = "",
    val time: String = "",
    val room: String = "",
    val department: String = "",
    val semester: String = ""
)

data class SeatPlanItem(
    @DocumentId val id: String = "",
    val roll: String = "",
    val room: String = "",
    val seatNo: String = ""
)

// ---------- eBook / Digital Library ----------
data class EbookCategory(
    @DocumentId val id: String = "",
    val name: String = "",
    val icon: String = ""
)

data class Ebook(
    @DocumentId val id: String = "",
    val title: String = "",
    val author: String = "",
    val description: String = "",
    val categoryId: String = "",
    val coverImageUrl: String = "",
    val pdfUrl: String = "",
    val uploadedAtMillis: Long = 0L
)

// ---------- Quiz Game ----------
data class QuizCategory(
    @DocumentId val id: String = "",
    val name: String = "",
    val icon: String = "",
    val questionCount: Int = 0
)

data class QuizQuestion(
    @DocumentId val id: String = "",
    val categoryId: String = "",
    val question: String = "",
    val options: List<String> = emptyList(),
    val correctIndex: Int = 0
)

data class LeaderboardEntry(
    @DocumentId val id: String = "",
    val rank: Int = 0,
    val name: String = "",
    val score: Int = 0,
    val badge: String = "",
    val studentId: String = ""
)

// ---------- Login / Student ----------
data class LoginDepartment(
    @DocumentId val id: String = "",
    val name: String = "",
    val icon: String = ""
)

data class Student(
    @DocumentId val id: String = "",
    val authUid: String = "",
    val name: String = "",
    val department: String = "",
    val session: String = "",
    val semester: String = "",
    val roll: String = "",
    val registration: String = "",
    val bloodGroup: String = "",
    val phone: String = "",
    val email: String = "",
    val guardianName: String = "",
    val guardianPhone: String = "",
    val address: String = "",
    val photoUrl: String = "",
    val fcmToken: String = ""
)

// ---------- Transcript ----------
data class TranscriptRow(
    @DocumentId val id: String = "",
    val studentId: String = "",
    val semester: String = "",
    val courseCode: String = "",
    val courseName: String = "",
    val credit: Double = 0.0,
    val grade: String = "",
    val gpa: Double = 0.0
)

// ---------- Attendance ----------
data class MonthlyAttendance(
    @DocumentId val id: String = "",
    val studentId: String = "",
    val month: String = "",
    val present: Int = 0,
    val absent: Int = 0,
    val late: Int = 0
)

// ---------- Case History ----------
data class CaseHistoryItem(
    @DocumentId val id: String = "",
    val studentId: String = "",
    val status: String = "",
    val date: String = "",
    val remarks: String = ""
)

// ---------- Evaluation ----------
data class EvaluationRow(
    @DocumentId val id: String = "",
    val studentId: String = "",
    val courseName: String = "",
    val assignment: Int = 0,
    val quiz: Int = 0,
    val mid: Int = 0,
    @get:PropertyName("final_exam") @set:PropertyName("final_exam")
    var finalExam: Int = 0,
    val practical: Int = 0,
    val remarks: String = ""
)

// ---------- Application ----------
data class ApplicationType(
    @DocumentId val id: String = "",
    val title: String = "",
    val icon: String = "",
    val description: String = ""
)

/** A student-submitted application/request, reviewed by Admin. */
data class ApplicationSubmission(
    @DocumentId val id: String = "",
    val studentId: String = "",
    val studentName: String = "",
    val typeId: String = "",
    val typeTitle: String = "",
    val reason: String = "",
    val attachmentUrl: String = "",
    val status: String = "Pending", // Pending, Approved, Rejected
    val adminRemarks: String = "",
    val submittedAtMillis: Long = 0L
)

// ---------- Diary & Task ----------
data class TaskItem(
    @DocumentId val id: String = "",
    val studentId: String = "",
    val title: String = "",
    val dueDate: String = "",
    val isDone: Boolean = false,
    val priority: String = "Normal"
)

// ---------- Library ----------
data class IssuedBook(
    @DocumentId val id: String = "",
    val studentId: String = "",
    val title: String = "",
    val issueDate: String = "",
    val returnDate: String = "",
    val fine: Double = 0.0
)

// ---------- Dashboard ----------
data class RoutinePeriod(
    @DocumentId val id: String = "",
    val day: String = "",
    val time: String = "",
    val subject: String = "",
    val teacher: String = "",
    val room: String = "",
    val department: String = "",
    val semester: String = ""
)

data class Teacher(
    @DocumentId val id: String = "",
    val name: String = "",
    val designation: String = "",
    val department: String = "",
    val phone: String = "",
    val email: String = "",
    val officeRoom: String = "",
    val photoUrl: String = ""
)

data class QuickAccessItem(
    @DocumentId val id: String = "",
    val title: String = "",
    val icon: String = "",
    val route: String = ""
)

// ---------- Dynamic Home content ----------
data class SliderImage(
    @DocumentId val id: String = "",
    val imageUrl: String = "",
    val caption: String = "",
    val linkRoute: String = ""
)

/** Single "current" document powering the Home screen's dynamic sections. */
data class HomeContent(
    val principalMessage: String = "",
    val sliderImages: List<SliderImage> = emptyList(),
    val announcements: List<String> = emptyList(),
    val quickLinks: List<QuickAccessItem> = emptyList()
)

// ---------- Events ----------
data class EventItem(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val date: String = "",
    val imageUrl: String = "",
    val location: String = ""
)

// ---------- Per-student eBook bookmark ----------
data class BookmarkEntry(
    @DocumentId val id: String = "", // convention: "{studentId}_{ebookId}"
    val studentId: String = "",
    val ebookId: String = ""
)

