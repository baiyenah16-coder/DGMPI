package com.dgmpi.app.data.remote

/** Centralized Firestore collection & Storage path names. Keep the Admin Panel schema in sync with this file. */
object FirestorePaths {
    const val STUDENTS = "students"
    const val TEACHERS = "teachers"
    const val NOTICES = "notices"
    const val ADMISSION_INFO = "admission_info"          // single doc: "current"
    const val RESULTS = "results"
    const val EXAM_ROUTINE = "exam_routine"
    const val SEAT_PLAN = "seat_plan"
    const val CLASS_ROUTINE = "class_routine"
    const val EBOOKS = "ebooks"
    const val EBOOK_CATEGORIES = "ebook_categories"
    const val QUIZ_CATEGORIES = "quiz_categories"
    const val QUIZ_QUESTIONS = "quiz_questions"
    const val LEADERBOARD = "leaderboard"
    const val GALLERY = "gallery"
    const val FACILITIES = "facilities"
    const val DEPARTMENTS = "departments"
    const val CAMPUS_INFO = "campus_info"                 // single doc: "current"
    const val EVENTS = "events"
    const val APPLICATIONS = "applications"
    const val ATTENDANCE = "attendance"
    const val CASE_HISTORY = "case_history"
    const val EVALUATIONS = "evaluations"
    const val TASKS = "tasks"
    const val ISSUED_BOOKS = "issued_books"
    const val HOME_CONTENT = "home_content"               // single doc: "current" (slider, announcements, quick links)
    const val APP_CONFIG = "app_config"                    // single doc: "current" (maintenance mode, min version)

    // Storage roots
    const val STORAGE_STUDENT_PHOTOS = "student_photos"
    const val STORAGE_TEACHER_PHOTOS = "teacher_photos"
    const val STORAGE_GALLERY = "gallery"
    const val STORAGE_NOTICE_ATTACHMENTS = "notice_attachments"
    const val STORAGE_EVENT_IMAGES = "event_images"
    const val STORAGE_EBOOK_FILES = "ebook_files"
    const val STORAGE_EBOOK_COVERS = "ebook_covers"
    const val STORAGE_SLIDER = "slider_images"
    const val STORAGE_TRANSCRIPT_PDF = "transcript_pdf"
}
