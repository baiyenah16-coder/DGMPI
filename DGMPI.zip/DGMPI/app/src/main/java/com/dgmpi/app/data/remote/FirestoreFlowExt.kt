package com.dgmpi.app.data.remote

import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.Query
import com.dgmpi.app.util.Resource
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * Observes a Firestore query in real time and emits [Resource] states. Because Firestore is
 * configured with persistent cache (see FirebaseModule), this also transparently serves cached
 * data offline and re-emits automatically the instant the server pushes a change — this is what
 * gives the app its "updates automatically when data changes online" behavior.
 */
inline fun <reified T : Any> Query.observeList(): Flow<Resource<List<T>>> = callbackFlow {
    trySend(Resource.Loading)
    val registration = addSnapshotListener { snapshot, error ->
        if (error != null) {
            trySend(Resource.Error(error.message ?: "Failed to load data", error))
            return@addSnapshotListener
        }
        val items = snapshot?.documents?.mapNotNull { it.toObject(T::class.java) } ?: emptyList()
        trySend(Resource.Success(items))
    }
    awaitClose { registration.remove() }
}

inline fun <reified T : Any> DocumentReference.observeDoc(): Flow<Resource<T?>> = callbackFlow {
    trySend(Resource.Loading)
    val registration = addSnapshotListener { snapshot, error ->
        if (error != null) {
            trySend(Resource.Error(error.message ?: "Failed to load data", error))
            return@addSnapshotListener
        }
        trySend(Resource.Success(snapshot?.toObject(T::class.java)))
    }
    awaitClose { registration.remove() }
}

suspend inline fun <reified T : Any> CollectionReference.getListOnce(): Resource<List<T>> = try {
    val snapshot = get().await()
    Resource.Success(snapshot.documents.mapNotNull { it.toObject(T::class.java) })
} catch (e: Exception) {
    Resource.Error(e.message ?: "Failed to load data", e)
}
