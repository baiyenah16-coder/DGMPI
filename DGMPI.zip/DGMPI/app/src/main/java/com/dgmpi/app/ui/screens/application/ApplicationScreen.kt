package com.dgmpi.app.ui.screens.application

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.dgmpi.app.data.model.ApplicationType
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GoldOutlineBadge
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.components.IconMapper
import com.dgmpi.app.ui.components.SectionCard
import com.dgmpi.app.ui.components.SectionTitle
import com.dgmpi.app.ui.theme.Gold
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.ui.theme.SuccessGreen
import com.dgmpi.app.ui.theme.WarningAmber
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.AppViewModel
import com.dgmpi.app.viewmodel.ApplicationViewModel

@Composable
fun ApplicationScreen(appViewModel: AppViewModel, onBack: () -> Unit, viewModel: ApplicationViewModel = hiltViewModel()) {
    val student by appViewModel.currentStudent.collectAsState()
    var selected by remember { mutableStateOf<ApplicationType?>(null) }
    var showHistory by remember { mutableStateOf(false) }

    LaunchedEffect(student?.id) { student?.id?.let { viewModel.bindStudent(it) } }

    Scaffold(
        topBar = {
            GradientHeader(
                title = "Application",
                subtitle = selected?.title ?: if (showHistory) "My Submissions" else "Submit an online request",
                onBack = {
                    when {
                        selected != null -> selected = null
                        showHistory -> showHistory = false
                        else -> onBack()
                    }
                },
                trailing = {
                    if (selected == null) {
                        TextButton(onClick = { showHistory = !showHistory }) {
                            Text(if (showHistory) "New" else "History", color = androidx.compose.ui.graphics.Color.White)
                        }
                    }
                }
            )
        }
    ) { padding ->
        when {
            selected != null -> ApplicationForm(
                type = selected!!,
                student = student,
                viewModel = viewModel,
                onSubmitted = { selected = null },
                paddingValues = padding
            )
            showHistory -> SubmissionHistory(viewModel, padding)
            else -> ApplicationTypeList(viewModel, padding) { selected = it }
        }
    }
}

@Composable
private fun ApplicationTypeList(viewModel: ApplicationViewModel, padding: PaddingValues, onSelect: (ApplicationType) -> Unit) {
    val typesState by viewModel.types.collectAsState()
    when (val state = typesState) {
        is Resource.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Navy)
        }
        is Resource.Error -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
            Text(state.message, color = MaterialTheme.colorScheme.error)
        }
        is Resource.Success -> {
            if (state.data.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(padding)) {
                    EmptyState("No application types configured yet.", modifier = Modifier.align(Alignment.Center))
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(state.data, key = { it.id }) { type ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            onClick = { onSelect(type) }
                        ) {
                            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier.size(44.dp).background(Gold.copy(alpha = 0.15f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(IconMapper.get(type.icon), contentDescription = null, tint = Navy)
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(type.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    Text(type.description, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SubmissionHistory(viewModel: ApplicationViewModel, padding: PaddingValues) {
    val submissionsState by viewModel.mySubmissions.collectAsState()
    when (val state = submissionsState) {
        is Resource.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Navy)
        }
        is Resource.Error -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
            Text(state.message, color = MaterialTheme.colorScheme.error)
        }
        is Resource.Success -> {
            if (state.data.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(padding)) {
                    EmptyState("You haven't submitted any applications yet.", icon = Icons.Filled.History, modifier = Modifier.align(Alignment.Center))
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(state.data, key = { it.id }) { submission ->
                        SectionCard {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(submission.typeTitle, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                val color = when (submission.status) {
                                    "Approved" -> SuccessGreen
                                    "Rejected" -> MaterialTheme.colorScheme.error
                                    else -> WarningAmber
                                }
                                GoldOutlineBadge(submission.status)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(submission.reason, style = MaterialTheme.typography.bodyMedium)
                            if (submission.adminRemarks.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Admin remarks: ${submission.adminRemarks}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ApplicationForm(
    type: ApplicationType,
    student: com.dgmpi.app.data.model.Student?,
    viewModel: ApplicationViewModel,
    onSubmitted: () -> Unit,
    paddingValues: PaddingValues
) {
    var reason by remember { mutableStateOf("") }
    var attachmentUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val submitState by viewModel.submitState.collectAsState()

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        attachmentUri = uri
    }

    LaunchedEffect(submitState) {
        if (submitState is Resource.Success) {
            onSubmitted()
            viewModel.clearSubmitState()
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(paddingValues).padding(16.dp)) {
        if (submitState is Resource.Loading) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))
        }
        SectionCard {
            Text(type.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(type.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = reason,
                onValueChange = { reason = it },
                label = { Text("Details / Reason") },
                modifier = Modifier.fillMaxWidth().height(140.dp),
                maxLines = 6
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedButton(onClick = { filePicker.launch("*/*") }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.AttachFile, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (attachmentUri != null) "Document selected" else "Attach Supporting Document")
            }
            if (submitState is Resource.Error) {
                Spacer(modifier = Modifier.height(8.dp))
                Text((submitState as Resource.Error).message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    val s = student ?: return@Button
                    viewModel.submit(s.id, s.name, type, reason, attachmentUri)
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Navy),
                enabled = reason.isNotBlank() && submitState !is Resource.Loading
            ) {
                Icon(Icons.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Submit Application", fontWeight = FontWeight.Bold)
            }
        }
    }
}
