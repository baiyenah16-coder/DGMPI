package com.dgmpi.app.navigation

data class SearchablePage(val title: String, val route: String, val keywords: List<String> = emptyList())

/** Flat index of every page in the app so the Home search bar can jump straight to a match. */
val searchIndex = listOf(
    SearchablePage("Our Campus", Routes.CAMPUS, listOf("campus", "principal", "departments", "gallery", "vision", "mission")),
    SearchablePage("Notice Board", Routes.NOTICE_BOARD, listOf("notice", "circular", "announcement")),
    SearchablePage("Admission", Routes.ADMISSION, listOf("admission", "apply", "eligibility", "fees")),
    SearchablePage("Result", Routes.RESULT, listOf("result", "roll", "gpa", "semester")),
    SearchablePage("Examination", Routes.EXAMINATION, listOf("exam", "routine", "seat plan")),
    SearchablePage("eBook", Routes.EBOOK, listOf("ebook", "library", "book", "pdf")),
    SearchablePage("Game", Routes.GAME, listOf("game", "quiz", "leaderboard")),
    SearchablePage("Dashboard", Routes.DASHBOARD, listOf("dashboard", "routine", "cgpa")),
    SearchablePage("Profile", Routes.PROFILE, listOf("profile", "student info")),
    SearchablePage("Transcript", Routes.TRANSCRIPT, listOf("transcript", "grade", "gpa")),
    SearchablePage("Attendance", Routes.ATTENDANCE, listOf("attendance", "present", "absent")),
    SearchablePage("Case History", Routes.CASE_HISTORY, listOf("case", "disciplinary")),
    SearchablePage("ID Card", Routes.ID_CARD, listOf("id card", "qr", "barcode")),
    SearchablePage("Evaluation Transcript", Routes.EVALUATION, listOf("evaluation", "marks")),
    SearchablePage("Application", Routes.APPLICATION, listOf("application", "leave", "certificate")),
    SearchablePage("Diary & Task", Routes.DIARY_TASK, listOf("diary", "task", "planner")),
    SearchablePage("Library", Routes.LIBRARY, listOf("library", "issued books"))
)

fun searchPages(query: String): List<SearchablePage> {
    if (query.isBlank()) return emptyList()
    val q = query.trim().lowercase()
    return searchIndex.filter { page ->
        page.title.lowercase().contains(q) || page.keywords.any { it.contains(q) }
    }
}
