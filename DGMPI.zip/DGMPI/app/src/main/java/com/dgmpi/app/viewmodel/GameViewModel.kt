package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.LeaderboardEntry
import com.dgmpi.app.data.model.QuizCategory
import com.dgmpi.app.data.model.QuizQuestion
import com.dgmpi.app.data.repository.QuizRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class GameViewModel @Inject constructor(
    repository: QuizRepository
) : ViewModel() {
    private val _categories = MutableStateFlow<Resource<List<QuizCategory>>>(Resource.Loading)
    val categories: StateFlow<Resource<List<QuizCategory>>> = _categories.asStateFlow()

    private val _leaderboard = MutableStateFlow<Resource<List<LeaderboardEntry>>>(Resource.Loading)
    val leaderboard: StateFlow<Resource<List<LeaderboardEntry>>> = _leaderboard.asStateFlow()

    init {
        viewModelScope.launch { repository.observeQuizCategories().collect { _categories.value = it } }
        viewModelScope.launch { repository.observeLeaderboard().collect { _leaderboard.value = it } }
    }
}

@HiltViewModel
class QuizPlayViewModel @Inject constructor(
    private val repository: QuizRepository
) : ViewModel() {
    private val _questions = MutableStateFlow<Resource<List<QuizQuestion>>>(Resource.Loading)
    val questions: StateFlow<Resource<List<QuizQuestion>>> = _questions.asStateFlow()

    private var loadedCategoryId: String? = null

    fun loadQuestions(categoryId: String) {
        if (loadedCategoryId == categoryId) return
        loadedCategoryId = categoryId
        viewModelScope.launch {
            repository.observeQuestions(categoryId).collect { _questions.value = it }
        }
    }

    fun submitScore(studentId: String, name: String, score: Int, badge: String) {
        viewModelScope.launch {
            repository.submitScore(studentId, name, score, badge)
        }
    }
}
