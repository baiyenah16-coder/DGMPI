package com.dgmpi.app.ui.screens.game

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.components.IconMapper
import com.dgmpi.app.ui.components.SectionCard
import com.dgmpi.app.ui.components.SectionTitle
import com.dgmpi.app.ui.theme.Gold
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.GameViewModel

@Composable
fun GameScreen(onBack: () -> Unit, onStartQuiz: (String) -> Unit, viewModel: GameViewModel = hiltViewModel()) {
    val categoriesState by viewModel.categories.collectAsState()
    val leaderboardState by viewModel.leaderboard.collectAsState()

    Scaffold(
        topBar = { GradientHeader(title = "Quiz Game", subtitle = "Learn while you play", onBack = onBack) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            SectionTitle("Choose a Quiz", Icons.Filled.SportsEsports)
            when (val state = categoriesState) {
                is Resource.Loading -> CircularProgressIndicator(color = Navy)
                is Resource.Error -> Text(state.message, color = MaterialTheme.colorScheme.error)
                is Resource.Success -> {
                    if (state.data.isEmpty()) {
                        EmptyState("No quizzes available yet.")
                    } else {
                        state.data.forEach { cat ->
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                                shape = RoundedCornerShape(16.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                onClick = { onStartQuiz(cat.id) }
                            ) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier.size(48.dp).background(Gold.copy(alpha = 0.15f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(IconMapper.get(cat.icon), contentDescription = null, tint = Navy)
                                    }
                                    Spacer(modifier = Modifier.width(14.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(cat.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("${cat.questionCount} questions • Timed", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Button(onClick = { onStartQuiz(cat.id) }, colors = ButtonDefaults.buttonColors(containerColor = Navy)) {
                                        Text("Play")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            SectionCard {
                SectionTitle("Leaderboard", Icons.Filled.EmojiEvents)
                when (val state = leaderboardState) {
                    is Resource.Loading -> CircularProgressIndicator(color = Navy)
                    is Resource.Error -> Text(state.message, color = MaterialTheme.colorScheme.error)
                    is Resource.Success -> {
                        if (state.data.isEmpty()) {
                            Text("No scores yet — be the first to play!", style = MaterialTheme.typography.bodyMedium)
                        } else {
                            state.data.forEachIndexed { index, entry ->
                                val rank = index + 1
                                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier.size(32.dp).background(
                                            if (rank <= 3) Gold.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                                            CircleShape
                                        ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("$rank", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(entry.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                        if (entry.badge.isNotBlank() && entry.badge != "-") {
                                            Text(entry.badge, style = MaterialTheme.typography.labelSmall, color = Gold)
                                        }
                                    }
                                    Text("${entry.score} pts", fontWeight = FontWeight.Bold, color = Navy)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
