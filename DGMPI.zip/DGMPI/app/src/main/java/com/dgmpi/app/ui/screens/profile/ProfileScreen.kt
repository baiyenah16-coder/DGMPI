package com.dgmpi.app.ui.screens.profile

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.components.SectionCard
import com.dgmpi.app.ui.components.SectionTitle
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.ui.theme.PureWhite
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.AppViewModel
import com.dgmpi.app.viewmodel.ProfileViewModel

@Composable
fun ProfileScreen(
    appViewModel: AppViewModel,
    onBack: () -> Unit,
    viewModel: ProfileViewModel = hiltViewModel()
) {
    val currentStudent by appViewModel.currentStudent.collectAsState()
    val studentState by viewModel.student.collectAsState()
    val isUploading by viewModel.isUploadingPhoto.collectAsState()

    LaunchedEffect(currentStudent?.id) {
        currentStudent?.id?.let { viewModel.bindStudent(it) }
    }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val id = currentStudent?.id
        if (uri != null && id != null) viewModel.uploadProfilePhoto(id, uri)
    }

    Scaffold(
        topBar = { GradientHeader(title = "Profile", subtitle = currentStudent?.name ?: "", onBack = onBack) }
    ) { padding ->
        when (val state = studentState) {
            is Resource.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Navy)
            }
            is Resource.Error -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(state.message, color = MaterialTheme.colorScheme.error)
            }
            is Resource.Success -> {
                val s = state.data
                if (s == null) {
                    Box(Modifier.fillMaxSize().padding(padding)) {
                        EmptyState("Student profile not found.", modifier = Modifier.align(Alignment.Center))
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                Box(
                                    modifier = Modifier.size(88.dp).background(Navy, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (s.photoUrl.isNotBlank()) {
                                        AsyncImage(model = s.photoUrl, contentDescription = null, modifier = Modifier.size(88.dp))
                                    } else {
                                        Icon(Icons.Filled.Person, contentDescription = null, tint = PureWhite, modifier = Modifier.size(44.dp))
                                    }
                                    if (isUploading) {
                                        CircularProgressIndicator(color = PureWhite, modifier = Modifier.size(88.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                TextButton(onClick = { photoPicker.launch("image/*") }) {
                                    Icon(Icons.Filled.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Change Photo")
                                }
                                Text(s.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text("Dhaka Gov. Mohila Polytechnic Institute", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        item {
                            SectionCard {
                                SectionTitle("Academic Information")
                                InfoRow("Department", s.department)
                                InfoRow("Session", s.session)
                                InfoRow("Semester", s.semester)
                                InfoRow("Roll", s.roll)
                                InfoRow("Registration Number", s.registration)
                            }
                        }
                        item {
                            SectionCard {
                                SectionTitle("Personal Information")
                                InfoRow("Blood Group", s.bloodGroup)
                                InfoRow("Phone", s.phone)
                                InfoRow("Email", s.email)
                                InfoRow("Address", s.address)
                            }
                        }
                        item {
                            SectionCard {
                                SectionTitle("Guardian Information")
                                InfoRow("Guardian Name", s.guardianName)
                                InfoRow("Guardian Phone", s.guardianPhone)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value.ifBlank { "-" }, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
    }
}
