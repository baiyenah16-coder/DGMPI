package com.dgmpi.app.navigation

import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.dgmpi.app.ui.components.AppDrawerContent
import com.dgmpi.app.ui.components.publicMenuEntries
import com.dgmpi.app.ui.components.studentMenuEntries
import com.dgmpi.app.ui.screens.admission.AdmissionScreen
import com.dgmpi.app.ui.screens.application.ApplicationScreen
import com.dgmpi.app.ui.screens.attendance.AttendanceScreen
import com.dgmpi.app.ui.screens.campus.CampusScreen
import com.dgmpi.app.ui.screens.casehistory.CaseHistoryScreen
import com.dgmpi.app.ui.screens.dashboard.StudentDashboardScreen
import com.dgmpi.app.ui.screens.diary.DiaryTaskScreen
import com.dgmpi.app.ui.screens.ebook.EbookScreen
import com.dgmpi.app.ui.screens.events.EventsScreen
import com.dgmpi.app.ui.screens.evaluation.EvaluationTranscriptScreen
import com.dgmpi.app.ui.screens.examination.ExaminationScreen
import com.dgmpi.app.ui.screens.gallery.GalleryScreen
import com.dgmpi.app.ui.screens.game.GameScreen
import com.dgmpi.app.ui.screens.game.QuizPlayScreen
import com.dgmpi.app.ui.screens.home.HomeScreen
import com.dgmpi.app.ui.screens.idcard.IdCardScreen
import com.dgmpi.app.ui.screens.library.LibraryScreen
import com.dgmpi.app.ui.screens.login.DepartmentSelectionScreen
import com.dgmpi.app.ui.screens.login.LoginScreen
import com.dgmpi.app.ui.screens.notice.NoticeBoardScreen
import com.dgmpi.app.ui.screens.profile.ProfileScreen
import com.dgmpi.app.ui.screens.result.ResultScreen
import com.dgmpi.app.ui.screens.settings.SettingsScreen
import com.dgmpi.app.ui.screens.transcript.TranscriptScreen
import com.dgmpi.app.viewmodel.AppViewModel
import kotlinx.coroutines.launch

/**
 * Single NavHost for the whole app. Two logical areas share one back stack:
 *  - Public area (Home + informational pages), reachable before login.
 *  - Student area (Dashboard + all student-only pages), reachable after login.
 * A single ModalNavigationDrawer is reused for both areas with different
 * menu entries depending on which "zone" the current route belongs to.
 */
@Composable
fun DgmpiNavGraph(appViewModel: AppViewModel) {
    val navController: NavHostController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val studentRoutes = setOf(
        Routes.DASHBOARD, Routes.PROFILE, Routes.TRANSCRIPT, Routes.ATTENDANCE,
        Routes.CASE_HISTORY, Routes.ID_CARD, Routes.EVALUATION, Routes.APPLICATION,
        Routes.DIARY_TASK, Routes.LIBRARY, Routes.SETTINGS
    )
    val isStudentZone = currentRoute in studentRoutes
    val drawerEntries = if (isStudentZone) studentMenuEntries else publicMenuEntries

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            AppDrawerContent(
                entries = drawerEntries,
                currentRoute = currentRoute,
                onItemClick = { entry ->
                    scope.launch { drawerState.close() }
                    navController.navigate(entry.route) { launchSingleTop = true }
                },
                onLogout = if (isStudentZone) {
                    {
                        scope.launch { drawerState.close() }
                        appViewModel.logout()
                        navController.navigate(Routes.HOME) { popUpTo(0) }
                    }
                } else null
            )
        }
    ) {
        NavHost(navController = navController, startDestination = Routes.HOME) {

            // ---------- Public area ----------
            composable(Routes.HOME) {
                HomeScreen(
                    onMenuClick = { scope.launch { drawerState.open() } },
                    onLoginClick = { navController.navigate(Routes.DEPARTMENT_SELECTION) },
                    onNavigate = { route -> navController.navigate(route) }
                )
            }
            composable(Routes.CAMPUS) {
                CampusScreen(onBack = { navController.popBackStack() }, onOpenGallery = { navController.navigate(Routes.GALLERY) })
            }
            composable(Routes.NOTICE_BOARD) { NoticeBoardScreen(onBack = { navController.popBackStack() }) }
            composable(Routes.ADMISSION) { AdmissionScreen(onBack = { navController.popBackStack() }) }
            composable(Routes.RESULT) { ResultScreen(onBack = { navController.popBackStack() }) }
            composable(Routes.EXAMINATION) { ExaminationScreen(onBack = { navController.popBackStack() }) }
            composable(Routes.EBOOK) { EbookScreen(appViewModel = appViewModel, onBack = { navController.popBackStack() }) }
            composable(Routes.GALLERY) { GalleryScreen(onBack = { navController.popBackStack() }) }
            composable(Routes.EVENTS) { EventsScreen(onBack = { navController.popBackStack() }) }
            composable(Routes.GAME) {
                GameScreen(
                    onBack = { navController.popBackStack() },
                    onStartQuiz = { categoryId -> navController.navigate(Routes.gameQuiz(categoryId)) }
                )
            }
            composable(Routes.GAME_QUIZ) { entry ->
                val categoryId = entry.arguments?.getString("categoryId") ?: ""
                QuizPlayScreen(
                    categoryId = categoryId,
                    appViewModel = appViewModel,
                    onBack = { navController.popBackStack() },
                    onFinish = { navController.popBackStack() }
                )
            }

            // ---------- Login flow ----------
            composable(Routes.DEPARTMENT_SELECTION) {
                DepartmentSelectionScreen(
                    onBack = { navController.popBackStack() },
                    onDepartmentSelected = { dept -> navController.navigate(Routes.login(dept)) }
                )
            }
            composable(Routes.LOGIN) { entry ->
                val department = entry.arguments?.getString("department") ?: "General"
                LoginScreen(
                    department = department,
                    appViewModel = appViewModel,
                    onBack = { navController.popBackStack() },
                    onLoginSuccess = {
                        navController.navigate(Routes.DASHBOARD) {
                            popUpTo(Routes.HOME) { inclusive = false }
                        }
                    }
                )
            }

            // ---------- Student area ----------
            composable(Routes.DASHBOARD) {
                StudentDashboardScreen(
                    appViewModel = appViewModel,
                    onMenuClick = { scope.launch { drawerState.open() } },
                    onNavigate = { route -> navController.navigate(route) }
                )
            }
            composable(Routes.PROFILE) { ProfileScreen(appViewModel = appViewModel, onBack = { navController.popBackStack() }) }
            composable(Routes.TRANSCRIPT) { TranscriptScreen(appViewModel = appViewModel, onBack = { navController.popBackStack() }) }
            composable(Routes.ATTENDANCE) { AttendanceScreen(appViewModel = appViewModel, onBack = { navController.popBackStack() }) }
            composable(Routes.CASE_HISTORY) { CaseHistoryScreen(appViewModel = appViewModel, onBack = { navController.popBackStack() }) }
            composable(Routes.ID_CARD) { IdCardScreen(appViewModel = appViewModel, onBack = { navController.popBackStack() }) }
            composable(Routes.EVALUATION) { EvaluationTranscriptScreen(appViewModel = appViewModel, onBack = { navController.popBackStack() }) }
            composable(Routes.APPLICATION) { ApplicationScreen(appViewModel = appViewModel, onBack = { navController.popBackStack() }) }
            composable(Routes.DIARY_TASK) { DiaryTaskScreen(appViewModel = appViewModel, onBack = { navController.popBackStack() }) }
            composable(Routes.LIBRARY) { LibraryScreen(appViewModel = appViewModel, onBack = { navController.popBackStack() }) }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    onBack = { navController.popBackStack() },
                    onLoggedOut = { navController.navigate(Routes.HOME) { popUpTo(0) } }
                )
            }
        }
    }
}
