package com.dgmpi.app.ui.screens.casehistory

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.components.SectionCard
import com.dgmpi.app.ui.components.SectionTitle
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.ui.theme.SuccessGreen
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.AcademicRecordsViewModel
import com.dgmpi.app.viewmodel.AppViewModel

@Composable
fun CaseHistoryScreen(appViewModel: AppViewModel, onBack: () -> Unit, viewModel: AcademicRecordsViewModel = hiltViewModel()) {
    val student by appViewModel.currentStudent.collectAsState()
    val caseHistoryState by viewModel.caseHistory.collectAsState()

    LaunchedEffect(student?.id) { student?.id?.let { viewModel.bindStudent(it) } }

    Scaffold(
        topBar = { GradientHeader(title = "Case History", subtitle = "Disciplinary record", onBack = onBack) }
    ) { padding ->
        when (val state = caseHistoryState) {
            is Resource.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Navy)
            }
            is Resource.Error -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(state.message, color = MaterialTheme.colorScheme.error)
            }
            is Resource.Success -> {
                if (state.data.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(padding)) {
                        EmptyState("No disciplinary records — clean record!", modifier = Modifier.align(Alignment.Center))
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item { SectionTitle("Record", Icons.Filled.History) }
                        items(state.data, key = { it.id }) { item ->
                            SectionCard {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text(item.status, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = SuccessGreen)
                                    Text(item.date, style = MaterialTheme.typography.labelSmall)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(item.remarks, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}
