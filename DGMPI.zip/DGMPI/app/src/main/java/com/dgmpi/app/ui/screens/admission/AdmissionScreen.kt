package com.dgmpi.app.ui.screens.admission

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.dgmpi.app.ui.components.*
import com.dgmpi.app.ui.theme.Gold
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.AdmissionViewModel

@Composable
fun AdmissionScreen(onBack: () -> Unit, viewModel: AdmissionViewModel = hiltViewModel()) {
    val state by viewModel.admissionInfo.collectAsState()

    Scaffold(
        topBar = { GradientHeader(title = "Admission", subtitle = "Current session", onBack = onBack) }
    ) { padding ->
        when (val resource = state) {
            is Resource.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Navy)
            }
            is Resource.Error -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(resource.message, color = MaterialTheme.colorScheme.error)
            }
            is Resource.Success -> {
                val info = resource.data
                if (info == null) {
                    Box(Modifier.fillMaxSize().padding(padding)) {
                        EmptyState("Admission information has not been published yet.", modifier = Modifier.align(Alignment.Center))
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            SectionCard {
                                SectionTitle("Admission Circular", Icons.Filled.Campaign)
                                Text(info.circularText, style = MaterialTheme.typography.bodyMedium)
                                if (info.circularPdfUrl.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                                    Button(onClick = { uriHandler.openUri(info.circularPdfUrl) }, colors = ButtonDefaults.buttonColors(containerColor = Navy)) {
                                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Download Circular PDF")
                                    }
                                }
                            }
                        }
                        if (info.eligibility.isNotEmpty()) item {
                            SectionCard {
                                SectionTitle("Eligibility", Icons.Filled.CheckCircle)
                                info.eligibility.forEach { BulletText(it) }
                            }
                        }
                        if (info.requiredDocuments.isNotEmpty()) item {
                            SectionCard {
                                SectionTitle("Required Documents", Icons.Filled.Description)
                                info.requiredDocuments.forEach { BulletText(it) }
                            }
                        }
                        if (info.applicationSteps.isNotEmpty()) item {
                            SectionCard {
                                SectionTitle("Application Process", Icons.Filled.Assignment)
                                info.applicationSteps.forEachIndexed { index, step ->
                                    Row(modifier = Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        IconBadge(icon = Icons.Filled.LooksOne, backgroundColor = Gold.copy(alpha = 0.15f))
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text("${index + 1}. $step", style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }
                        if (info.fees.isNotEmpty()) item {
                            SectionCard {
                                SectionTitle("Fees", Icons.Filled.Payments)
                                info.fees.forEach { (label, value) -> FeeRow(label, value) }
                            }
                        }
                        if (info.importantDates.isNotEmpty()) item {
                            SectionCard {
                                SectionTitle("Important Dates", Icons.Filled.Event)
                                info.importantDates.forEach { d ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(d.label, style = MaterialTheme.typography.bodyMedium)
                                        Text(d.date, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }
                        if (info.faqs.isNotEmpty()) item {
                            SectionCard {
                                SectionTitle("Frequently Asked Questions", Icons.Filled.QuestionAnswer)
                                info.faqs.forEach { faq -> FaqRow(faq.question, faq.answer) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BulletText(text: String) {
    Row(modifier = Modifier.padding(vertical = 3.dp)) {
        Text("•  ", fontWeight = FontWeight.Bold, color = Navy)
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun FeeRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, fontWeight = FontWeight.Bold, color = Navy)
    }
}

@Composable
private fun FaqRow(question: String, answer: String) {
    var expanded by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { expanded = !expanded }
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(question, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Icon(if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore, contentDescription = null, tint = Navy)
        }
        if (expanded) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(answer, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    Divider()
}
