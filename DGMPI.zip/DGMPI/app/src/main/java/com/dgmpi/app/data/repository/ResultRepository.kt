package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.ResultRecord
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.data.remote.getListOnce
import com.dgmpi.app.util.Resource
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

interface ResultRepository {
    suspend fun searchByRoll(roll: String, semester: String): Resource<ResultRecord>
    suspend fun searchByRegistration(registration: String, semester: String): Resource<ResultRecord>
}

@Singleton
class ResultRepositoryImpl @Inject constructor(
    private val firestore: FirebaseFirestore
) : ResultRepository {

    override suspend fun searchByRoll(roll: String, semester: String): Resource<ResultRecord> = try {
        var query = firestore.collection(FirestorePaths.RESULTS)
            .whereEqualTo("roll", roll.trim())
            .whereEqualTo("published", true)
        if (semester.isNotBlank()) query = query.whereEqualTo("semester", semester.trim())
        val snapshot = query.limit(1).get().await()
        val record = snapshot.documents.firstOrNull()?.toObject(ResultRecord::class.java)
        if (record != null) Resource.Success(record) else Resource.Error("No published result found for this roll number")
    } catch (e: Exception) {
        Resource.Error(e.message ?: "Failed to search result", e)
    }

    override suspend fun searchByRegistration(registration: String, semester: String): Resource<ResultRecord> = try {
        var query = firestore.collection(FirestorePaths.RESULTS)
            .whereEqualTo("registration", registration.trim())
            .whereEqualTo("published", true)
        if (semester.isNotBlank()) query = query.whereEqualTo("semester", semester.trim())
        val snapshot = query.limit(1).get().await()
        val record = snapshot.documents.firstOrNull()?.toObject(ResultRecord::class.java)
        if (record != null) Resource.Success(record) else Resource.Error("No published result found for this registration number")
    } catch (e: Exception) {
        Resource.Error(e.message ?: "Failed to search result", e)
    }
}
