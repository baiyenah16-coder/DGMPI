package com.dgmpi.app.ui.screens.library

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocalLibrary
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.components.SectionCard
import com.dgmpi.app.ui.components.SectionTitle
import com.dgmpi.app.ui.theme.ErrorRed
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.ui.theme.SuccessGreen
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.AppViewModel
import com.dgmpi.app.viewmodel.LibraryViewModel

@Composable
fun LibraryScreen(appViewModel: AppViewModel, onBack: () -> Unit, viewModel: LibraryViewModel = hiltViewModel()) {
    val student by appViewModel.currentStudent.collectAsState()
    val issuedState by viewModel.issuedBooks.collectAsState()

    LaunchedEffect(student?.id) { student?.id?.let { viewModel.bindStudent(it) } }

    Scaffold(
        topBar = { GradientHeader(title = "Library", subtitle = "Issued books & digital resources", onBack = onBack) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                SectionCard {
                    SectionTitle("Issued Books", Icons.Filled.MenuBook)
                    when (val state = issuedState) {
                        is Resource.Loading -> CircularProgressIndicator(color = Navy)
                        is Resource.Error -> Text(state.message, color = MaterialTheme.colorScheme.error)
                        is Resource.Success -> {
                            if (state.data.isEmpty()) {
                                Text("You have no books currently issued.", style = MaterialTheme.typography.bodyMedium)
                            } else {
                                state.data.forEach { book ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(book.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                            Text("Return by: ${book.returnDate}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        if (book.fine > 0) {
                                            Text("Fine: ৳${book.fine.toInt()}", color = ErrorRed, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                        } else {
                                            Text("On time", color = SuccessGreen, style = MaterialTheme.typography.labelMedium)
                                        }
                                    }
                                    Divider()
                                }
                            }
                        }
                    }
                }
            }
            item {
                SectionCard {
                    SectionTitle("Digital Resources", Icons.Filled.LocalLibrary)
                    Text(
                        "Access thousands of digital resources including journals, past papers, and reference " +
                            "materials through the eBook Library section.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}
