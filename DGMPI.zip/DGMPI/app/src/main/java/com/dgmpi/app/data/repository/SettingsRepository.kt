package com.dgmpi.app.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "dgmpi_settings")
private val DARK_THEME_KEY = booleanPreferencesKey("dark_theme_enabled")
private val NOTIFICATIONS_KEY = booleanPreferencesKey("push_notifications_enabled")

interface SettingsRepository {
    fun observeDarkTheme(): Flow<Boolean>
    suspend fun setDarkTheme(enabled: Boolean)
    fun observeNotificationsEnabled(): Flow<Boolean>
    suspend fun setNotificationsEnabled(enabled: Boolean)
}

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : SettingsRepository {

    override fun observeDarkTheme(): Flow<Boolean> =
        context.dataStore.data.map { it[DARK_THEME_KEY] ?: false }

    override suspend fun setDarkTheme(enabled: Boolean) {
        context.dataStore.edit { it[DARK_THEME_KEY] = enabled }
    }

    override fun observeNotificationsEnabled(): Flow<Boolean> =
        context.dataStore.data.map { it[NOTIFICATIONS_KEY] ?: true }

    override suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[NOTIFICATIONS_KEY] = enabled }
    }
}
