package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.Notice
import com.dgmpi.app.data.model.RoutinePeriod
import com.dgmpi.app.data.model.Teacher
import com.dgmpi.app.data.repository.NoticeRepository
import com.dgmpi.app.data.repository.RoutineRepository
import com.dgmpi.app.data.repository.TeacherRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val routineRepository: RoutineRepository,
    teacherRepository: TeacherRepository,
    noticeRepository: NoticeRepository
) : ViewModel() {

    private val _teachers = MutableStateFlow<Resource<List<Teacher>>>(Resource.Loading)
    val teachers: StateFlow<Resource<List<Teacher>>> = _teachers.asStateFlow()

    private val _latestNotice = MutableStateFlow<Resource<Notice?>>(Resource.Loading)
    val latestNotice: StateFlow<Resource<Notice?>> = _latestNotice.asStateFlow()

    private val _routine = MutableStateFlow<Resource<List<RoutinePeriod>>>(Resource.Loading)
    val routine: StateFlow<Resource<List<RoutinePeriod>>> = _routine.asStateFlow()

    private var routineJob: Job? = null
    private var boundKey: String? = null

    init {
        viewModelScope.launch { teacherRepository.observeTeachers().collect { _teachers.value = it } }
        viewModelScope.launch {
            noticeRepository.observeNotices().collect { resource ->
                _latestNotice.value = resource.map { it.firstOrNull() }
            }
        }
    }

    fun bindStudent(department: String, semester: String) {
        val key = "$department|$semester"
        if (boundKey == key) return
        boundKey = key
        routineJob?.cancel()
        routineJob = viewModelScope.launch {
            routineRepository.observeRoutine(department, semester).collect { _routine.value = it }
        }
    }
}
