package com.dgmpi.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dgmpi.app.ui.theme.Gold
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.ui.theme.NavyDark
import com.dgmpi.app.ui.theme.PureWhite

/** Gradient navy->deep-navy header used across feature screens, with an optional gold accent bar. */
@Composable
fun GradientHeader(
    title: String,
    subtitle: String? = null,
    showBack: Boolean = true,
    onBack: (() -> Unit)? = null,
    onMenuClick: (() -> Unit)? = null,
    trailing: @Composable (() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(NavyDark, Navy)))
            .padding(horizontal = 20.dp, vertical = 18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (showBack) {
                IconButton(onClick = { onBack?.invoke() }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = PureWhite)
                }
            } else if (onMenuClick != null) {
                IconButton(onClick = onMenuClick) {
                    Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = PureWhite)
                }
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = if (showBack || onMenuClick != null) 4.dp else 0.dp)
            ) {
                Text(
                    text = title,
                    color = PureWhite,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        color = PureWhite.copy(alpha = 0.75f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            trailing?.invoke()
        }
        Spacer(modifier = Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .width(56.dp)
                .height(3.dp)
                .background(Gold, shape = MaterialTheme.shapes.small)
        )
    }
}

@Composable
fun NotificationAction(onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Icon(Icons.Filled.Notifications, contentDescription = "Notifications", tint = PureWhite)
    }
}
