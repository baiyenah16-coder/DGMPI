package com.dgmpi.app.ui.screens.ebook

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.dgmpi.app.data.model.Ebook
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.components.IconMapper
import com.dgmpi.app.ui.components.SectionTitle
import com.dgmpi.app.ui.theme.Gold
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.AppViewModel
import com.dgmpi.app.viewmodel.EbookViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EbookScreen(
    appViewModel: AppViewModel,
    onBack: () -> Unit,
    viewModel: EbookViewModel = hiltViewModel()
) {
    var query by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    val ebooksState by viewModel.ebooks.collectAsState()
    val categoriesState by viewModel.categories.collectAsState()
    val bookmarkedIds by viewModel.bookmarkedIds.collectAsState()
    val student by appViewModel.currentStudent.collectAsState()

    LaunchedEffect(student?.id) {
        student?.id?.let { viewModel.bindStudent(it) }
    }

    val allBooks = (ebooksState as? Resource.Success)?.data ?: emptyList()
    val categories = (categoriesState as? Resource.Success)?.data ?: emptyList()
    val filtered = allBooks.filter { book ->
        (selectedCategory == null || book.categoryId == selectedCategory) &&
            (query.isBlank() || book.title.contains(query, ignoreCase = true) || book.author.contains(query, ignoreCase = true))
    }

    Scaffold(
        topBar = { GradientHeader(title = "eBook Library", subtitle = "${allBooks.size} books available", onBack = onBack) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Column(modifier = Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search title or author") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                SectionTitle("Categories")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        FilterChip(selected = selectedCategory == null, onClick = { selectedCategory = null }, label = { Text("All") })
                    }
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat.id,
                            onClick = { selectedCategory = if (selectedCategory == cat.id) null else cat.id },
                            label = { Text(cat.name) },
                            leadingIcon = { Icon(IconMapper.get(cat.icon), contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )
                    }
                }
            }

            when (val state = ebooksState) {
                is Resource.Loading -> Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Navy)
                }
                is Resource.Error -> Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(state.message, color = MaterialTheme.colorScheme.error)
                }
                is Resource.Success -> {
                    if (filtered.isEmpty()) {
                        EmptyState("No books match your search.")
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(filtered, key = { it.id }) { book ->
                                BookRow(
                                    book = book,
                                    isBookmarked = book.id in bookmarkedIds,
                                    onBookmarkToggle = { viewModel.toggleBookmark(book.id) }
                                )
                            }
                            item { Spacer(modifier = Modifier.height(16.dp)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BookRow(book: Ebook, isBookmarked: Boolean, onBookmarkToggle: () -> Unit) {
    val uriHandler = LocalUriHandler.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (book.coverImageUrl.isNotBlank()) {
                AsyncImage(
                    model = book.coverImageUrl,
                    contentDescription = book.title,
                    modifier = Modifier.size(56.dp).background(Gold.copy(alpha = 0.18f), RoundedCornerShape(10.dp))
                )
            } else {
                Box(
                    modifier = Modifier.size(56.dp).background(Gold.copy(alpha = 0.18f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.MenuBook, contentDescription = null, tint = Navy)
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(book.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                Text(book.author, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(6.dp))
                Row {
                    TextButton(onClick = { if (book.pdfUrl.isNotBlank()) uriHandler.openUri(book.pdfUrl) }, contentPadding = PaddingValues(0.dp)) {
                        Icon(Icons.Filled.MenuBook, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Open", style = MaterialTheme.typography.labelSmall)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    TextButton(onClick = { if (book.pdfUrl.isNotBlank()) uriHandler.openUri(book.pdfUrl) }, contentPadding = PaddingValues(0.dp)) {
                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Download", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            IconButton(onClick = onBookmarkToggle) {
                Icon(
                    if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                    contentDescription = "Bookmark",
                    tint = Gold
                )
            }
        }
    }
}
