package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.CaseHistoryItem
import com.dgmpi.app.data.model.EvaluationRow
import com.dgmpi.app.data.model.MonthlyAttendance
import com.dgmpi.app.data.model.TranscriptRow
import com.dgmpi.app.data.repository.AcademicRecordsRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AcademicRecordsViewModel @Inject constructor(
    private val repository: AcademicRecordsRepository
) : ViewModel() {

    private val _attendance = MutableStateFlow<Resource<List<MonthlyAttendance>>>(Resource.Loading)
    val attendance: StateFlow<Resource<List<MonthlyAttendance>>> = _attendance.asStateFlow()

    private val _caseHistory = MutableStateFlow<Resource<List<CaseHistoryItem>>>(Resource.Loading)
    val caseHistory: StateFlow<Resource<List<CaseHistoryItem>>> = _caseHistory.asStateFlow()

    private val _evaluations = MutableStateFlow<Resource<List<EvaluationRow>>>(Resource.Loading)
    val evaluations: StateFlow<Resource<List<EvaluationRow>>> = _evaluations.asStateFlow()

    private val _transcript = MutableStateFlow<Resource<List<TranscriptRow>>>(Resource.Loading)
    val transcript: StateFlow<Resource<List<TranscriptRow>>> = _transcript.asStateFlow()

    private var boundId: String? = null

    fun bindStudent(studentId: String) {
        if (boundId == studentId) return
        boundId = studentId
        viewModelScope.launch { repository.observeAttendance(studentId).collect { _attendance.value = it } }
        viewModelScope.launch { repository.observeCaseHistory(studentId).collect { _caseHistory.value = it } }
        viewModelScope.launch { repository.observeEvaluations(studentId).collect { _evaluations.value = it } }
        viewModelScope.launch { repository.observeTranscript(studentId).collect { _transcript.value = it } }
    }
}
