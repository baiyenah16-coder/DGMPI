package com.dgmpi.app.ui.screens.game

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.theme.Gold
import com.dgmpi.app.ui.theme.Navy
import com.dgmpi.app.ui.theme.SuccessGreen
import com.dgmpi.app.util.Resource
import com.dgmpi.app.viewmodel.AppViewModel
import com.dgmpi.app.viewmodel.QuizPlayViewModel
import kotlinx.coroutines.delay

@Composable
fun QuizPlayScreen(
    categoryId: String,
    appViewModel: AppViewModel,
    onBack: () -> Unit,
    onFinish: () -> Unit,
    viewModel: QuizPlayViewModel = hiltViewModel()
) {
    val questionsState by viewModel.questions.collectAsState()
    val student by appViewModel.currentStudent.collectAsState()

    LaunchedEffect(categoryId) { viewModel.loadQuestions(categoryId) }

    Scaffold(
        topBar = { GradientHeader(title = "Quiz", subtitle = "Test your knowledge", onBack = onBack) }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            when (val state = questionsState) {
                is Resource.Loading -> CircularProgressIndicator(color = Navy, modifier = Modifier.align(Alignment.Center))
                is Resource.Error -> Text(state.message, color = MaterialTheme.colorScheme.error, modifier = Modifier.align(Alignment.Center))
                is Resource.Success -> {
                    if (state.data.isEmpty()) {
                        EmptyState("No questions available for this quiz yet.", modifier = Modifier.align(Alignment.Center))
                    } else {
                        QuizBody(
                            questions = state.data,
                            onSubmitScore = { score, badge ->
                                student?.let { viewModel.submitScore(it.id, it.name, score, badge) }
                            },
                            onFinish = onFinish
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QuizBody(
    questions: List<com.dgmpi.app.data.model.QuizQuestion>,
    onSubmitScore: (Int, String) -> Unit,
    onFinish: () -> Unit
) {
    var questionIndex by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var selectedOption by remember { mutableStateOf<Int?>(null) }
    var timeLeft by remember { mutableStateOf(20) }
    var finished by remember { mutableStateOf(false) }

    LaunchedEffect(questionIndex, finished) {
        if (finished) return@LaunchedEffect
        timeLeft = 20
        while (timeLeft > 0 && selectedOption == null) {
            delay(1000)
            timeLeft--
        }
        if (selectedOption == null) {
            if (questionIndex + 1 < questions.size) questionIndex++ else finished = true
        }
    }

    if (finished) {
        val maxScore = questions.size * 10
        val badge = when {
            score >= maxScore * 0.8 -> "Gold Achiever"
            score >= maxScore * 0.5 -> "Silver Achiever"
            else -> "Keep Practicing"
        }
        LaunchedEffect(Unit) { onSubmitScore(score, badge) }
        QuizResultView(score = score, total = questions.size, badge = badge, onDone = onFinish)
        return
    }

    val question = questions[questionIndex]

    Column(modifier = Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Timer, contentDescription = null, tint = if (timeLeft <= 5) Color.Red else Navy)
                Spacer(modifier = Modifier.width(4.dp))
                Text("${timeLeft}s", fontWeight = FontWeight.Bold, color = if (timeLeft <= 5) Color.Red else Navy)
            }
            Text("Score: $score", fontWeight = FontWeight.Bold, color = Gold)
        }

        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = timeLeft / 20f,
            modifier = Modifier.fillMaxWidth().height(6.dp),
            color = if (timeLeft <= 5) Color.Red else Navy
        )
        Spacer(modifier = Modifier.height(24.dp))

        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
            Text(question.question, modifier = Modifier.padding(20.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(16.dp))

        question.options.forEachIndexed { index, option ->
            val isCorrect = index == question.correctIndex
            val isSelected = selectedOption == index
            OutlinedButton(
                onClick = {
                    if (selectedOption == null) {
                        selectedOption = index
                        if (isCorrect) score += 10
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = when {
                        selectedOption != null && isCorrect -> SuccessGreen.copy(alpha = 0.15f)
                        isSelected && !isCorrect -> Color.Red.copy(alpha = 0.12f)
                        else -> MaterialTheme.colorScheme.surface
                    }
                )
            ) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(option, modifier = Modifier.weight(1f))
                    if (selectedOption != null && isCorrect) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = SuccessGreen)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        AnimatedVisibility(visible = selectedOption != null) {
            Button(
                onClick = {
                    selectedOption = null
                    if (questionIndex + 1 < questions.size) questionIndex++ else finished = true
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Navy)
            ) {
                Text(if (questionIndex == questions.lastIndex) "Finish" else "Next Question")
            }
        }
    }
}

@Composable
private fun QuizResultView(score: Int, total: Int, badge: String, onDone: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(modifier = Modifier.size(96.dp).background(Gold.copy(alpha = 0.18f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = Gold, modifier = Modifier.size(56.dp))
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text("Quiz Complete!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))
        Text("You scored $score / ${total * 10}", style = MaterialTheme.typography.titleMedium, color = Navy)
        Spacer(modifier = Modifier.height(4.dp))
        Text(badge, style = MaterialTheme.typography.bodyMedium, color = Gold, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = onDone, colors = ButtonDefaults.buttonColors(containerColor = Navy)) { Text("Back to Games") }
    }
}
