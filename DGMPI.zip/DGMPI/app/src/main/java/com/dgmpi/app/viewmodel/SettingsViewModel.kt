package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.repository.AuthRepository
import com.dgmpi.app.data.repository.SettingsRepository
import com.dgmpi.app.util.Resource
import com.google.firebase.messaging.FirebaseMessaging
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val NOTICES_TOPIC = "dgmpi_all_students"

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val authRepository: AuthRepository,
    private val firebaseMessaging: FirebaseMessaging
) : ViewModel() {

    private val _darkTheme = MutableStateFlow(false)
    val darkTheme: StateFlow<Boolean> = _darkTheme.asStateFlow()

    private val _notificationsEnabled = MutableStateFlow(true)
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    private val _changePasswordState = MutableStateFlow<Resource<Unit>?>(null)
    val changePasswordState: StateFlow<Resource<Unit>?> = _changePasswordState.asStateFlow()

    init {
        viewModelScope.launch { settingsRepository.observeDarkTheme().collect { _darkTheme.value = it } }
        viewModelScope.launch {
            settingsRepository.observeNotificationsEnabled().collect { enabled ->
                _notificationsEnabled.value = enabled
                if (enabled) firebaseMessaging.subscribeToTopic(NOTICES_TOPIC)
                else firebaseMessaging.unsubscribeFromTopic(NOTICES_TOPIC)
            }
        }
    }

    fun setDarkTheme(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setDarkTheme(enabled) }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setNotificationsEnabled(enabled) }
    }

    fun changePassword(currentPassword: String, newPassword: String) {
        viewModelScope.launch {
            _changePasswordState.value = Resource.Loading
            _changePasswordState.value = authRepository.changePassword(currentPassword, newPassword)
        }
    }

    fun clearChangePasswordState() {
        _changePasswordState.value = null
    }

    fun logout() {
        viewModelScope.launch { authRepository.logout() }
    }
}
