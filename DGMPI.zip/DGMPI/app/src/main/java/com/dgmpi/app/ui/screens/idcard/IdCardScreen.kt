package com.dgmpi.app.ui.screens.idcard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.asImageBitmap
import coil.compose.AsyncImage
import com.dgmpi.app.ui.components.EmptyState
import com.dgmpi.app.ui.components.GradientHeader
import com.dgmpi.app.ui.theme.*
import com.dgmpi.app.util.QrCodeGenerator
import com.dgmpi.app.viewmodel.AppViewModel

@Composable
fun IdCardScreen(appViewModel: AppViewModel, onBack: () -> Unit) {
    val student by appViewModel.currentStudent.collectAsState()

    Scaffold(
        topBar = { GradientHeader(title = "Digital ID Card", subtitle = "Show this at the gate", onBack = onBack) }
    ) { padding ->
        val s = student
        if (s == null) {
            Box(Modifier.fillMaxSize().padding(padding)) {
                EmptyState("Loading your ID card...", modifier = Modifier.align(Alignment.Center))
            }
            return@Scaffold
        }

        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(NavyDark, Navy))).padding(20.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.School, contentDescription = null, tint = Gold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Dhaka Gov. Mohila Polytechnic Institute", color = PureWhite, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(72.dp).background(PureWhite, CircleShape), contentAlignment = Alignment.Center) {
                            if (s.photoUrl.isNotBlank()) {
                                AsyncImage(model = s.photoUrl, contentDescription = null, modifier = Modifier.size(72.dp))
                            } else {
                                Icon(Icons.Filled.Person, contentDescription = null, tint = Navy, modifier = Modifier.size(36.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(s.name, color = PureWhite, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(s.department, color = PureWhite.copy(alpha = 0.8f), style = MaterialTheme.typography.labelSmall)
                            Text("Roll: ${s.roll}", color = Gold, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    IdDetailRow("Registration", s.registration)
                    IdDetailRow("Session", s.session)
                    IdDetailRow("Blood Group", s.bloodGroup)
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                        Box(
                            modifier = Modifier.height(36.dp).width(140.dp).background(PureWhite, RoundedCornerShape(4.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("‖ ‖‖ ‖ ‖‖‖ ‖ ‖‖ ‖‖‖", color = NavyDark, style = MaterialTheme.typography.labelSmall)
                        }
                        Box(modifier = Modifier.size(56.dp).background(PureWhite, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                            val qrBitmap = remember(s.id) {
                                QrCodeGenerator.generate("DGMPI|${s.id}|${s.roll}|${s.registration}", sizePx = 200)
                            }
                            androidx.compose.foundation.Image(
                                bitmap = qrBitmap.asImageBitmap(),
                                contentDescription = "QR Code",
                                modifier = Modifier.size(52.dp)
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "This digital ID is valid for the current academic session only.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun IdDetailRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = PureWhite.copy(alpha = 0.65f), style = MaterialTheme.typography.labelSmall)
        Text(value.ifBlank { "-" }, color = PureWhite, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
    }
}
