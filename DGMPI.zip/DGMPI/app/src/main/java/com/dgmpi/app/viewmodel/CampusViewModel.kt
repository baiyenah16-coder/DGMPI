package com.dgmpi.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dgmpi.app.data.model.CampusInfo
import com.dgmpi.app.data.model.Department
import com.dgmpi.app.data.model.FacilityItem
import com.dgmpi.app.data.model.GalleryImage
import com.dgmpi.app.data.repository.CampusRepository
import com.dgmpi.app.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class CampusViewModel @Inject constructor(
    private val repository: CampusRepository
) : ViewModel() {

    private val _campusInfo = MutableStateFlow<Resource<CampusInfo?>>(Resource.Loading)
    val campusInfo: StateFlow<Resource<CampusInfo?>> = _campusInfo.asStateFlow()

    private val _departments = MutableStateFlow<Resource<List<Department>>>(Resource.Loading)
    val departments: StateFlow<Resource<List<Department>>> = _departments.asStateFlow()

    private val _facilities = MutableStateFlow<Resource<List<FacilityItem>>>(Resource.Loading)
    val facilities: StateFlow<Resource<List<FacilityItem>>> = _facilities.asStateFlow()

    private val _gallery = MutableStateFlow<Resource<List<GalleryImage>>>(Resource.Loading)
    val gallery: StateFlow<Resource<List<GalleryImage>>> = _gallery.asStateFlow()

    private var galleryJob: kotlinx.coroutines.Job? = null

    init {
        viewModelScope.launch { repository.observeCampusInfo().collect { _campusInfo.value = it } }
        viewModelScope.launch { repository.observeDepartments().collect { _departments.value = it } }
        viewModelScope.launch { repository.observeFacilities().collect { _facilities.value = it } }
        loadGallery(null)
    }

    fun loadGallery(category: String?) {
        galleryJob?.cancel()
        _gallery.value = Resource.Loading
        galleryJob = viewModelScope.launch {
            repository.observeGallery(category).collect { _gallery.value = it }
        }
    }
}
