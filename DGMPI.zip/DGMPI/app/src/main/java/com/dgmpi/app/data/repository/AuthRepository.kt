package com.dgmpi.app.data.repository

import com.dgmpi.app.data.model.Student
import com.dgmpi.app.data.remote.FirestorePaths
import com.dgmpi.app.util.Resource
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

interface AuthRepository {
    val isLoggedIn: Boolean
    val currentUserId: String?
    fun observeAuthState(): Flow<Boolean>
    suspend fun login(email: String, password: String): Resource<String>
    suspend fun logout()
    suspend fun fetchCurrentStudent(): Resource<Student>
    suspend fun updateFcmToken(token: String)
    suspend fun changePassword(currentPassword: String, newPassword: String): Resource<Unit>
}

@Singleton
class AuthRepositoryImpl @Inject constructor(
    private val auth: FirebaseAuth,
    private val firestore: FirebaseFirestore
) : AuthRepository {

    override val isLoggedIn: Boolean
        get() = auth.currentUser != null

    override val currentUserId: String?
        get() = auth.currentUser?.uid

    override fun observeAuthState(): Flow<Boolean> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser != null)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    override suspend fun login(email: String, password: String): Resource<String> = try {
        val result = auth.signInWithEmailAndPassword(email, password).await()
        val uid = result.user?.uid ?: return Resource.Error("Login failed — no user returned")
        Resource.Success(uid)
    } catch (e: Exception) {
        Resource.Error(e.message ?: "Invalid email or password", e)
    }

    override suspend fun logout() {
        auth.signOut()
    }

    override suspend fun fetchCurrentStudent(): Resource<Student> {
        val uid = currentUserId ?: return Resource.Error("Not logged in")
        return try {
            val snapshot = firestore.collection(FirestorePaths.STUDENTS)
                .whereEqualTo("authUid", uid)
                .limit(1)
                .get()
                .await()
            val student = snapshot.documents.firstOrNull()?.toObject(Student::class.java)
                ?: return Resource.Error("No student profile linked to this account")
            Resource.Success(student)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to load student profile", e)
        }
    }

    override suspend fun updateFcmToken(token: String) {
        val uid = currentUserId ?: return
        try {
            val snapshot = firestore.collection(FirestorePaths.STUDENTS)
                .whereEqualTo("authUid", uid)
                .limit(1)
                .get()
                .await()
            snapshot.documents.firstOrNull()?.reference?.update("fcmToken", token)?.await()
        } catch (_: Exception) {
            // Non-fatal: token sync retried on next app open via FirebaseMessagingService.
        }
    }

    override suspend fun changePassword(currentPassword: String, newPassword: String): Resource<Unit> {
        val user = auth.currentUser ?: return Resource.Error("Not logged in")
        val email = user.email ?: return Resource.Error("This account has no email on file")
        return try {
            val credential = com.google.firebase.auth.EmailAuthProvider.getCredential(email, currentPassword)
            user.reauthenticate(credential).await()
            user.updatePassword(newPassword).await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Failed to change password", e)
        }
    }
}
